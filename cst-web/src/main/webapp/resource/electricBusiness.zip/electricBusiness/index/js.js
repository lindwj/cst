//var width=$(".bannerbox").width();
var i=-1;
var timer=0;
$(document).ready(function () {

    move();
    timer=setInterval("move()",3000);
    $(".bannerbox ul li").hover(function(){
        clearInterval(timer);
    },function(){
        timer=setInterval("move()",3000);
    });
    //$('.nav dl dd').click(function(){
    //    var ddIndex=$(this).index()-1;
    //    i=ddIndex;
    //    move();
    //})
});


function move(){
    var bannernum = $(".bannerlist li").length;

    i++;
    if(i>=bannernum){
        i=0;
    }
    if(0<=i<bannernum){
        $('.nav dl dd').removeClass('bg');
        $('.nav dl dd').eq(i).addClass('bg');
        $('.bannerbox ul li').eq(i).fadeIn(100).siblings().fadeOut();
    }

}

