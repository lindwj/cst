


$(function () {
/*
    ////公告
   $(".black_box").show().delay(2500).fadeOut();*/


    //获取登录后进入的订单管理的链接
    var ajaxURL = product_url;
    $.ajax({
        type: 'POST',
        url: ajaxURL,
        dataType : "json" ,
        data: {},

        success:
            function(data){

                //显示首页banner
                getbannerList(data.indexBannerList);
                //显示首页商品
                getOrderList(data.pList);


            },
        error:
            function(data,textStatus){


            }

    });






    //解析json数据，页面显示
    function getbannerList(jnfo) {
        var banners = "";
        $.each(jnfo,function(x,xtem){

            banners += "<li class='li"+ (x+1) +"' data-url='"+ xtem.productUrl +"'>"
                +     "<img src='"+ xtem.bannerUrl +"'></li>";

        });
        $(".bannerlist").append(banners);


        var bannernum = $(".bannerlist li").length;

        for(var a=0;a<bannernum;a++){

            if(a==0){
                $(".circles").append("<dd class='bg'></dd>");
                for(var x =2;x<=bannernum;x++){
                    $(".li"+ x +"").css("display","none");
                }
                //var liurl = $(".li1").attr("data-url");
                //var imgurl = $(".li1>img").attr("src");
                //$(".bannerlist").append("<li class='li1' data-url='"+ liurl +"'><img src='"+ imgurl +"'></li>");
            }else{
                $(".circles").append("<dd class=''></dd>");
            }
            $(".li"+(a+1)+"").click(function(){
                var url = $(this).attr("data-url");
                if(url == "null"){
                    return false;
                }else{
                    window.open(url);
                }

            });

        }


        $('.nav dl dd').click(function(){
            var ddIndex=$(this).index()-1;
            i=ddIndex;
            move();
        });



    }

    //解析json数据，页面显示
    function getOrderList(info) {

        var product1 = "";
        var product2 = "";
        var product1_else = "";
        var product1_else1 = "";
        var product2_else = "";
        var product2_else1 = "";


        $.each(info, function (i, item) {


            if(i == 0){
                product1 = "";
            }else{
                product1_else1 = "";
                product1_else = "";
                product2_else1 = "";
                product2_else = "";



                product1 = "<div class='floor1'>"
                    + "<div class='title1'>"
                    + "<p>" + item.parameterName + "</p>"
                    + "<a class='look' href='#' data-id='" + i + "'>查看全部<i class='iconfont wicon'>&#xe621;</i>"
                    + "</a>"
                    + "</div>"
                    + "<div class='clear'>"
                    + "</div>"
                    + "<ul class='lfloor1'>";


                if (item.productList.length > 0) {

                    $.each(item.productList, function (n, ntem) {

                        var price = ntem.price;

                        if( price == 100000){
                            ntem.price = "即将上线";

                            if (n == 0) {

                                product1_else = "<li class='product8' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    + "<img src=\"" + ntem.pic + "\"/>"
                                    + "</div>"
                                    + "<h1>" + ntem.name + "</h1>"
                                    + "<p>" + ntem.price + "</p>"
                                    + "</li>";


                            }
                            else if (n == 4) {
                                product2_else = "<li class='product8' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    + "<img src=\"" + ntem.pic + "\"/>"
                                    + "</div>"
                                    + "<h1>" + ntem.name + "</h1>"
                                    + "<p>" + ntem.price + "</p>"
                                    + "</li>"
                            } else if (0 < n && n < 4) {
                                product1_else1 += "<li class='product7' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    + "<img src=\"" + ntem.pic + "\"/>"
                                    + "</div>"
                                    + "<h1>" + ntem.name + "</h1>"
                                    + "<p>" + ntem.price + "</p>"
                                    + "</li>";

                            } else if (4 < n && n< 8) {
                                product2_else1 += "<li class='product7' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    + "<img src=\"" + ntem.pic + "\"/>"
                                    + "</div>"
                                    + "<h1>" + ntem.name + "</h1>"
                                    + "<p>" + ntem.price + "</p>"
                                    + "</li>"
                            }


                        }else{

                            ntem.price = ntem.price;
                            if (n == 0) {

                                product1_else = "<li class='product8' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    + "<img src=\"" + ntem.pic + "\"/>"
                                    + "</div>"
                                    + "<h1>" + ntem.name + "</h1>"
                                    + "<p>￥" + ntem.price.toFixed(2) + "</p>"
                                    + "</li>";


                            }
                            else if (n == 4) {
                                product2_else = "<li class='product8' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    + "<img src=\"" + ntem.pic + "\"/>"
                                    + "</div>"
                                    + "<h1>" + ntem.name + "</h1>"
                                    + "<p>￥" + ntem.price.toFixed(2) + "</p>"
                                    + "</li>"
                            } else if (0 < n && n < 4) {
                                product1_else1 += "<li class='product7' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    + "<img src=\"" + ntem.pic + "\"/>"
                                    + "</div>"
                                    + "<h1>" + ntem.name + "</h1>"
                                    + "<p>￥" + ntem.price.toFixed(2) + "</p>"
                                    + "</li>";

                            } else if (4 < n && n< 8) {
                                product2_else1 += "<li class='product7' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    + "<img src=\"" + ntem.pic + "\"/>"
                                    + "</div>"
                                    + "<h1>" + ntem.name + "</h1>"
                                    + "<p>￥" + ntem.price.toFixed(2) + "</p>"
                                    + "</li>"
                            }
                        }


                    });


                    product1_else = product1_else + product1_else1 + product2_else + product2_else1 + "</ul>" + "<div class='clear'>" + "</div>" + "</div>";

                    product2 += product1 + product1_else;
                }

            }


        });

        $(".allproduct").append(product2);



        $(".product7").click(function(){
            var pid= $(this).attr("data-id");
            window.open(pro_url + pid);
        });
        $(".product8").click(function(){
            var pid= $(this).attr("data-id");
            window.open(pro_url + pid);
        });



        $(".look").click(function(){
            var code = $(this).attr("data-id");
            window.open(view_url + '?code=' + code);
        })


    }


});


