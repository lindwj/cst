
$(function(){

    var o=window.location.href.split("?")[1];

    $.ajax({
        type:'post',
        url:orderDetail_url,
        dataType:'json',
        data:o,
        success:
            function(data){
                getdetail(data);
            },
        error:
            function(data){
                error("请先登录后再访问！");
                window.location.href= login_url;
            }
    });

    var time= "";
    var order = "";
    var order1 = "";
    function getdetail(info){

        time = "<div class='time'>"
            +  "<p style='width: 500px;'>下单时间:<span>"+ info.createDatestr +"</span></p>"
            +  "<p>订单号:<span>"+ info.code +"</span></p>"
            +  "<div class='clear'></div>"
            +  "</div>"
            +  "<ul class='list' style='width: 480px;'>"
            +  "<li>收<span style='margin-left: 6px;'></span>货<span style='margin-left: 6px;'></span>人:<span>"+ info.receiveName +"</span></li>"
            +  "<li>联系方式:<span>"+ info.receiveMobile +"</span></li>"
            +  "<li>收货地址:<span>"+ info.receiveAddress +"</span></li>"
            +  "</ul>"
            +  "<ul class='list' style='width: 480px;margin-left: 20px;'>"
            +  "<li>商品合计:<span>￥"+ info.totalFromBdh.toFixed(2) +"</span></li>"
            +  "<li>送货店铺:<span>"+ info.shopName +"</span></li>"
            +  "<li>备<span style='margin-left: 23px;'></span>注:<span>"+ info.note +"</span></li>"
            +  "</ul>"
            +  "<div class='clear'></div>";
        $(".dbox").append(time);

        var order2 = "";
        var uuid = info.productUuid;

        order1 = "<table class='table' cellpadding='0' cellspacing='0'>"
            +    "<thead>"
            +    "<tr>"
            +    "<th class='col1' id='"+ uuid +"'>商品</th>"
            +    "<th class='col2'>单价</th>"
            +    "<th class='col3'>数量</th>"
            +    "<th class='col4'>小计</th>"
            +    "<th class='col5'>实付款</th>"
            +    "<th class='col6'>交易状态</th>"
            +    "</tr>"
            +    "</thead>"
            +    "<tbody>";

        var xx = info.ordersDetailList.length;
        var totalprice = info.totalFromBdh.toFixed(2);
        var state = info.status;
        $.each(info.ordersDetailList,function(i,item){

            if(uuid != 0){

                order2 = order2 + "<tr>"
                    +    "<th class='col7'>"
                    +    "<img src='"+ item.pic +"'>"
                    +    "<span>"+ item.subject +"</span>"
                    +    "</th>"
                    +    "<th class='col8'>"+ item.price.toFixed(2) +"</th>"
                    +    "<th class='col9'>"+ item.capacity +"</th>"
                    +    "<th class='col10'>"+ (item.capacity*item.price).toFixed(2) +"</th>"
                    +    "<th class='col11'>"+ totalprice +"<br>(含运费)</th>";
                if(state == 9){
                    order2 = order2 + "<th class='col12'>待付款</th>"+ "</tr>";
                }else if(state == 1){
                    order2 = order2 + "<th class='col12'>待收货</th>"+ "</tr>";
                }else if(state == 2){
                    order2 = order2 + "<th class='col12'>已签收</th>"+ "</tr>";
                }


            }else{

                if(i == 0){
                    order2 = order2 + "<tr>"
                        +    "<th class='col7'>"
                        +    "<img src='"+ item.pic +"'>"
                        +    "<span>"+ item.productName +"</span>"
                        +    "</th>"
                        +    "<th class='col8'>"+ item.price.toFixed(2) +"</th>"
                        +    "<th class='col9'>"+ item.capacity +"</th>"
                        +    "<th class='col10'>"+ (item.capacity*item.price).toFixed(2) +"</th>"
                        +    "<th class='col11' rowspan='"+ xx +"'>"+ totalprice +"<br>(含运费)</th>";
                    if(state == 9){
                        order2 = order2 + "<th class='col12' rowspan='"+ xx +"'>待付款</th>"+ "</tr>";
                    }else if(state == 1){
                        order2 = order2 + "<th class='col12' rowspan='"+ xx +"'>待收货</th>"+ "</tr>";
                    }else if(state == 2){
                        order2 = order2 + "<th class='col12' rowspan='"+ xx +"'>已签收</th>"+ "</tr>";
                    }
                }else{
                    order2 = order2 + "<tr>"
                        +    "<th class='col7'>"
                        +    "<img src='"+ item.pic +"'>"
                        +    "<span>"+ item.productName +"</span>"
                        +    "</th>"
                        +    "<th class='col8'>"+ item.price.toFixed(2) +"</th>"
                        +    "<th class='col9'>"+ item.capacity +"</th>"
                        +    "<th class='col10'>"+ (item.capacity*item.price).toFixed(2) +"</th>"
                        +    "</tr>";
                }


            }

        });

        order = order1 + order2;
        $(".orders_box").append(order);


    }
});
