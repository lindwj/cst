
//var base_url = "http://www.beidahuang.com";
//var base_url = "http://192.168.0.235:8080/business-web";
//var base_url = "http://192.168.0.245:8080/business-web";
//var base_url = "http://www.beidahuang.com";
//var bas_url = "http://localhost:63342";
//var base_url = "http://localhost:8080/business-web";
var base_url = "http://192.168.0.235:8080/business-web";
//var base_url = "http://121.41.17.4:9000";






//查看全部
var view_url = base_url + "/resource/electricBusiness/showAll.html";
//首页
var index_url = base_url + "/resource/electricBusiness/index.html";
//隐藏页面
var hide_url = base_url + "/resource/electricBusiness/hideFile.html";
//公司简介
var introduce_url = base_url + "/resource/electricBusiness/aboutUs.html";
//合作代理
var hzdl_url = base_url + "/resource/electricBusiness/hzdl.html";
//登录页面
var login_url = base_url + "/resource/jsp/login.jsp";
//注册页面
var register_url = base_url + "/resource/jsp/signup.jsp";
//产品链接
var pro_url = base_url + "/resource/electricBusiness/productDetail.html?productUuid=";
//确认下单页面
var orderUp_path = base_url + "/resource/electricBusiness/orderUp.html";
//收货地址
var address_url = base_url + "/resource/electricBusiness/myAddress.html";
//我的订单
var myorder_url = base_url + "/resource/electricBusiness/myOrder.html";
//订单支付跳转页面
var orderPay_url = base_url + "/orders/ordersPay.do?code=";
//订单详情页面
var orderDetail_path = base_url + "/resource/electricBusiness/orderDetail.html?code=";
//立即购买跳转的下单页面
var buy_url = base_url + "/resource/electricBusiness/orderNow.html";
//购物车链接
var shop_url = base_url + "/resource/electricBusiness/shoppingMarket.html";



//接口
//登录请求
var loginTest_url = base_url + "/user/isLoginSvc.do";
//退出
var logout_url = base_url + "/user/logout.do";
//首页数据加载接口
var product_url = base_url + "/indexBanner/indexBannerAddEditIniSvc.do";
//商品详情页
var prodetail_url = base_url + "/product/productDetailSvc.do?productUuid=";
//购物车商品添加接口
var market_url = base_url + "/cart/cartAddEdit.do";
//购物车商品列表接口
var marketpro_url = base_url + "/product/cartProductSvcListPage.do";
//删除
var delet_url = base_url + "/cart/cartDeleteSvc.do";
//批量删除
var delall_url = base_url + "/cart/cartDeleteAllSvc.do";
//结算数据加载接口
var orderUp_url = base_url + "/orders/ordersAddEditDetailIniSvc.do";
//添加地址接口
var addressAdd_url = base_url + "/goodsAddress/goodsAddressAdd.do";
//修改地址接口
var addressEdit_url = base_url + "/goodsAddress/goodsAddressEditSvc.do";
//删除地址接口
var addressDelete_url = base_url + "/goodsAddress/goodsAddressDeleteSvc.do";
//默认地址接口
var addressDefault_url = base_url + "/goodsAddress/goodsAddressDefault.do";
//三级联动接口
var select_url = base_url + "/nation/getNation.do";
//地址回填查询接口
var search_url = base_url + "/goodsAddress/goodsAddressAddEditIniSvc.do";
//地址列表加载接口
var alladdress_url = base_url + "/goodsAddress/goodsAddressListPageSvc.do";
//订单管理加载接口
var orderControl_url = base_url + "/orders/ordersListPageSvc.do";
//订单详情
var orderDetail_url = base_url + "/orders/ordersDetailSvc.do";
//立即购买接口
var nowpay_url = base_url + "/orders/ordersAddEditIniSvc.do";
//判断是否登录
var islogin_url = base_url + "/user/isLoginWx.do";
//去支付宝支付
var pay_url = base_url + "/orders/ordersPay.do?code=";
//立即购买进入的确认下单
var fsure_url = base_url + "/orders/ordersAddEdit.do";
//匹配店ID和店名
var shopid_url = base_url + "/orders/getShop.do";
//购物车进入的确认下单接口
var shoporder_url = base_url + "/ordersAddEditDetail.do";
//合作代理接口
var contact_url = base_url + "/TellUs/addTellUs.do";


var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?ec24d4cfebffa6fa8eb206bb4c00fbcc";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();


//弹框提示方法
function error(error){
  $(".alert").text(error);
  $(".alert").fadeIn();
  $(".alert").fadeOut(3000);
}