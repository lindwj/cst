$(function(){







    //默认显示第一页的数据
    var localObj = window.location;
    var contextPath = localObj.pathname.split("/")[1];
    var basePath = localObj.protocol+"//"+localObj.host+"/"+contextPath;
    var server_context=basePath;

    //获取登录后进入的订单管理的链接
    var ajaxURL =  product_url;
    $.ajax({
        type: 'POST',
        url: ajaxURL,
        dataType : "json" ,
        async:false,
        data: {},

        success:
            function(data,textStatus){

                //显示订单管理第一页数据
                getOrderList(data);


            },
        error:
            function(data,textStatus){


            }

    });




    var basket = "";
    var menubox = "";
    //解析json数据，页面显示
    function getOrderList(info) {



        //购物车
        basket ="<h1 class='welcome'>首页</h1>"
            +   "<span class='lines'>|</span>"
            +   "<h1 class='gsjj'>公司简介</h1>"
            +   "<span class='lines'>|</span>"
            +   "<h1 class='hzdl'>诚招总代理</h1>"
            +   "<div>"
            +   "<div id='shopbasket'>"
            +   "<a class='shop' href='"+shop_url+"'>"
            +   "<i class='iconfont carIcon' >&#xe600;</i>"
            +   "购物车("
            +   "<b id='cart-num'>"+ info.num +"</b>"
            +   ")</a>"
            +   "</div>"
            +   "<div id='user'>"
            +   "</div>"
            +   "</div>";


        $(".header").append(basket);


        menubox ="<div class='menu'>"
            +    "<a class='logo' href='"+ index_url +"'>"
            +    "<img src='images/logo3.jpg' />"
            +    "</a>"
            +    "<ul class='classification'>"
            +    "</ul>"
            +    "</div>";

        $(".menubox").append(menubox);

        var menu = "";


        $.each(info.pList, function (i, item) {

            if( i == 0 ){
                menu = "";
            }else{
                menu += "<li>"
                    +  "<a class='view_all' data-id='"+i+"' data-uuid='"+ item.parameterId +"'>"+ item.parameterName +"</a>"
                    +  "</li>";
            }

        });
        menu = "<li>" +  "<a id='indexurl' href='"+index_url+"'>首页</a>" +  "</li>" + menu;

        $(".classification").append(menu);

        $(".view_all").click(function(){
            var code = $(this).attr("data-id");
            window.location.href = 'showAll.html' + '?code=' + code;
        })





    }

    var ajaxURL = loginTest_url;
    $.ajax({
        type: 'POST',
        url: ajaxURL,
        dataType : "json" ,
        async:false,
        data: {},

        success:
            function(data){


                var header = "";
                var header1 = "";
                var header2 = "";

                if(data.status == 1){
                    //登录状态下按钮显示
                    header1 = "<a class='logout'>退出</a>"
                        +    "<a class='address'>收货地址<span>|</span></a>"
                        +    "<a class='myorder'>我的订单<span>|</span></a>";
                    if(data.nickname == null){
                        header2 = "<a class='user'>"+data.mobile+"<span>|</span></a>"
                    }else{
                        header2 = "<a class='user'>"+data.nickname+"<span>|</span></a>"
                    }
                    header = header1 + header2;
                    $("#user").append(header);
                }else{
                    //非登录状态下按钮显示
                    var name = "登录";
                    var order = "注册";
                    header = "<a class='register'>"+order+"</a><a class='login'>"+name+"<span>|</span></a>";
                    $("#user").append(header);
                }

            },
        error:
            function(data,textStatus){
                alert("服务器异常，请稍后重试！")

            }

    });

    //首页
    $(".welcome").click(function() {
        window.location.href= index_url;
    });
    //公司简介
    $(".gsjj").click(function() {
        window.open(introduce_url);
    });

    //合作代理
    $(".hzdl").click(function() {
        window.open(hzdl_url);
    });


    //登录
    $(".login").click(function() {
        window.location.href= login_url;
    });

    //注册
    $(".register").click(function() {
        window.location.href= register_url;
    });

    //我的订单
    $(".myorder").click(function() {
        window.location.href= myorder_url;
    });

    //收货地址
    $(".address").click(function() {
        window.location.href= address_url;
    });

    //退出
    $(".logout").click(function() {
        window.location.href= logout_url;
    });

});

