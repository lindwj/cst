$(function(){







    //默认显示第一页的数据
    var localObj = window.location;
    var contextPath = localObj.pathname.split("/")[1];
    var basePath = localObj.protocol+"//"+localObj.host+"/"+contextPath;
    var server_context=basePath;

    //获取登录后进入的订单管理的链接
    var ajaxURL =  product_url;
    $.ajax({
        type: 'POST',
        url: ajaxURL,
        dataType : "json" ,
        async:false,
        data: {},

        success:
            function(data,textStatus){

                //显示订单管理第一页数据
                getOrderList(data);


            },
        error:
            function(data,textStatus){


            }

    });




    var footer1 = "";
    var footer2 = "";
    //解析json数据，页面显示
    function getOrderList(info) {

        footer1 = "<div class='footer'>"
            +     "<img src='http://bdhec.oss-cn-hangzhou.aliyuncs.com/note/foot.jpg'>"
            //+     "<div class='hang1'>"
            //+     "<p style='width: 21%;'>"
            //+     "<i class='iconfont ficon2'>&#xe630;</i>"
            //+     "基地直供"
            //+     "</p>"
            //+     "<span class='line3'>"
            //+     "</span>"
            //+     "<p style='text-align:center;'>"
            //+     "<i class='iconfont ficon'>&#xe62e;</i>"
            //+     "放心食品"
            //+     "</p>"
            //+     "<span class='line3'>"
            //+     "</span>"
            //+     "<p style='text-align:center;'>"
            //+     "<i class='iconfont ficon1'>&#xe62f;</i>"
            //+     "安全检测"
            //+     "</p>"
            //+     "<span class='line3'>"
            //+     "</span>"
            //+     "<p style='text-align: right;width: 21%;'>"
            //+     "<i class='iconfont ficon1'>&#xe6c7;</i>"
            //+     "品质保证"
            //+     "</p>"
            +     "<span class='line4'>"
            +     "</span>"
            //+     "</div>"
            +     "</div>";

        $(".footerbox").append(footer1);

        footer2 = "<div class='footer1'>"
            +     "<img class='flogo' src='images/logo3.jpg' />"
            +     "<ul class='lianjie'>"
            //+     "<li>"
            //+     "<a href='#'>公司介绍</a>"
            //+     "<span>|</span>"
            //+     "</li>"
            //+     "<li>"
            //+     "<a href='#'>门店查询</a>"
            //+     "<span>|</span>"
            //+     "</li>"
            //+     "<li>"
            //+     "<a href='#'>人才招聘</a>"
            //+     "<span>|</span>"
            //+     "</li>"
            //+     "<li>"
            //+     "<a href='#'>合作代理</a>"
            //+     "<span>|</span>"
            //+     "</li>"

            //+     "<li>"
            //+     "<a class='introduce'>公司简介</a>"
            //+     "</li>"
            +     "<li>"
            +     "<a>客服热线 400-863-1119&nbsp;&nbsp;&nbsp;</a>"
            +     "</li>"
            +     "<li>"
            +     "<a>为耕者谋利&nbsp;&nbsp;&nbsp;</a>"
            +     "</li>"
            +     "<li>"
            +     "<a>为食者造福</a>"
            +     "</li>"
            +     "<div class='fmiddle'>"
            +     "<p class='xinxi'>"
            //+     "<i class='ba'><img src='images/ba.png>'></i>"
            +     "<span class='link1'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;苏公网安备：32020202000098号</span>&nbsp;&nbsp;&nbsp;<span class='link2'>苏ICP备16015588号</span>&nbsp;&nbsp;&nbsp;食品流通许可证编号 JY13202020009651&nbsp;&nbsp;&nbsp;<br />Copyright © 2016-2017 北大荒生态食品无锡有限公司 All Right Reserved</p>"
            +     "</div>"
            +     "</ul>"
            +     "<div class='weixin'>"
            +     "<div class='gzh'>"
            +     "<img src='/resource/electricBusiness/images/fwh.png' />"
            +     "<h1>微信服务号</h1>"
            +     "</div>"
            +     "<div class='fwh'>"
            +     "<img src='/resource/electricBusiness/images/gzh.png' />"
            +     "<h1>微信订阅号</h1>"
            +     "</div>"
            +     "</div>"
            +     "</div>";

        $(".footer1box").append(footer2);


        $(".introduce").click(function(){
            window.open(introduce_url);
        });
        $(".link1").click(function(){
            window.open('http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=32020202000098');
        });

        $(".link2").click(function(){
            window.open('http://www.miitbeian.gov.cn/');
        });

    }



});

