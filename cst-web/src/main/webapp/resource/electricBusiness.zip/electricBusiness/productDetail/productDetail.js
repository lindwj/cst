function cart(obj){

    var showCapacity = $("#plusmarket").attr("data-Capacity");
    var capacity = parseInt($("#numchange").val());


        if(capacity>showCapacity){
            error("商品库存不足");
            return false;
        }

    var productUuid = $("#plusmarket").attr("data-uuid");
    var ajaxURL = market_url;

    jQuery.ajax({
        url: ajaxURL,
        cache : false,
        data : {
            num:capacity,
            productUuid:productUuid
        },
        success :
            function(data) {

                if (1 == data) {
                    //mv();
                    var num = parseInt($("#cart-num").text());
                    num = num + capacity;
                    $("#cart-num").text(num);
                }
            },
        error:
            function(data,textStatus){


            }
    });
}

$(function(){





    var prouuid = window.location.href.split("=")[1];
    var ajaxURL = prodetail_url + prouuid;
    $.ajax({
        type: 'POST',
        url: ajaxURL,
        dataType : "json" ,
        data: {},

        success:
            function(data){

                getOrderList(data);


            },
        error:
            function(data,textStatus){


            }

    });




    $("#arrleft").click(function(){
        $(".proclass").animate({marginLeft:-960*0},800)
    });
    $("#arrright").click(function(){
        $(".proclass").animate({marginLeft:-960*1},800)
    });





    var menu = "";
    var prodetail = "";
    var prodetail1 = "";
    var prodetail2 = "";
    var prosize = "";
    var pic1 = "";
    var pic2 = "";
    var psee = "";
    var dmessage = "";
    var picclass = "";
    //解析json数据，页面显示
    function getOrderList(info) {


        $("meta[name='Keywords']").attr("content",""+ info.keywords +"");
        $("meta[name='description']").attr("content",""+ info.descriptionSeo +"");
        $("title").text("北大荒生态食品 - " + info.name +"");

        //商品详情菜单
        menu = "<li>"
            +  "<a href='"+index_url+"'>首页</a>"
            +  "</li>"
            +  "<li>"
            +  "<a href='javascript:;'>"
            +  "<i class='iconfont menuarrow'>&#xe63d;</i>" + info.name +"</a>"
            +  "</li>";

        $(".promenu").append(menu);





        $.each(info.productPicList, function (i, item) {
            if(i==0){
                //图组
                pic1 = "<div class='fpic'>"
                    + "<img class='img' src='" + item.picUrl +"' alt=''>"
                    + "</div>"
                    + "<ul class='spicbox'>";
            }

            pic2 += "<li class='spic'><img src='"+ item.picUrl +"'></li>";

        });

        pic1 += pic2 + "</ul>";


        $(".headLeft").append(pic1);

        $(".img").attr("alt",""+ info.name +"");
        //鼠标进入显示当前图片
        $(".spic").mouseenter(function(){
            $(".img").attr("src",$(this).find("img").attr("src"));
        });




        //商品详细购买信息
        var shopname ="";
        if(info.dowhat != '0'){
            shopname = "由&nbsp;" + info.shopName  + "&nbsp;配送";
        }else {
            shopname = "本地区暂不支持配送";
        }

        var address = "";
        if(info.goodsAddress.districtstr == null){
            address = "";
        }else{
            address = info.goodsAddress.districtstr;
        }

        if( info.price == "100000"){
            prodetail1 = "<h1 class='productName'>" + info.name +"</h1>"
                +       "<p class='prodes'>"+ info.describes +"</p>"
                +       "<div class='pricebox'>"
                +       "<div class='price'>"
                +       "<p class='p1'>售价</p>"
                +       "<p class='p2'>即将上线</p>"
                +       "<div class='clear'>"
                +       "</div>"
                +       "</div>"
                +       "<div class='price'>"
                +       "<p class='p1'>配送</p>"
                +       "<span class='p3'>" + info.goodsAddress.provincestr  + " " + info.goodsAddress.citystr  + " " + address  + "</span>"
                +       "<div class='clear'>"
                +       "</div>"
                +       "<p class='p1'>提示</p>"
                +       "<span class='p3'>"+ shopname+"</span>"
                +       "<div class='clear'>"
                +       "</div>"
                +       "</div>"
                +       "<div class='clear'>"
                +       "</div>"
                +       "</div>"
                +       "<div class='size'>"
                +       "<p>规格</p>";
        }else{
            prodetail1 = "<h1 class='productName'>" + info.name +"</h1>"
                +       "<p class='prodes'>"+ info.describes +"</p>"
                +       "<div class='pricebox'>"
                +       "<div class='price'>"
                +       "<p class='p1'>售价</p>"
                +       "<p class='p2'><span>￥</span>" + info.price.toFixed(2) +"</p>"
                +       "<div class='clear'>"
                +       "</div>"
                +       "</div>"
                +       "<div class='price'>"
                +       "<p class='p1'>配送</p>"
                +       "<span class='p3'>" + info.goodsAddress.provincestr  + " " + info.goodsAddress.citystr  + " " + address  + "</span>"
                +       "<div class='clear'>"
                +       "</div>"
                +       "<p class='p1'>提示</p>"
                +       "<span class='p3'>"+ shopname+"</span>"
                +       "<div class='clear'>"
                +       "</div>"
                +       "</div>"
                +       "<div class='clear'>"
                +       "</div>"
                +       "</div>"
                +       "<div class='size'>"
                +       "<p>规格</p>";
        }



        $.each(info.productAttributeList, function (i, item) {

            prosize +=  "<span id='sizepick'>"+ item.name +" : "+ item.value +""+ item.unit +"<i class='iconfont sizeicon'>&#xe6e8;</i>"
                +       "</span>";

        });

        if( info.showCapacity <= 0 || info.showCapacity == null ||  info.showCapacity == "" || info.price == "100000" ){

            prodetail2 = "<div class='clear'>"
                +       "</div>"
                +       "</div>"
                +       "<div class='number'>"
                +       "<p>数量</p>"
                +       "<span id='numminus'>"
                +       "<i class='iconfont plicon'>&#xe65b;</i>"
                +       "</span>"
                +       "<input id='numchange' name='hayden' type='text' value='1'>"
                +       "<span id='numplus'>"
                +       "<i class='iconfont plicon'>&#xe639;</i>"
                +       "</span>"
                +       "<div class='clear'>"
                +       "</div>"
                +       "</div>"
                +       "<div class='button'>"
                +       "<a href='javascript:;' id='stopbuy' data-Capacity='"+ info.showCapacity +"' data-uuid='"+ info.productUuid +"' >立即购买</a>"
                    //+       "<img  src='" + info.pic +"'>"
                    //+       "<a href='#' class='addcar' id='plusmarket' onclick='cart(this)' data-Capacity='"+ info.showCapacity +"' data-uuid='"+ info.productUuid +"'>"
                +       "<a href='javascript:;' class='addcar' id='stopplus' data-Capacity='"+ info.showCapacity +"' data-uuid='"+ info.productUuid +"'>"
                +       "暂时缺货</a>"
                +       "</div>";

        }
        else{

            prodetail2 = "<div class='clear'>"
                +       "</div>"
                +       "</div>"
                +       "<div class='number'>"
                +       "<p>数量</p>"
                +       "<span id='numminus'>"
                +       "<i class='iconfont plicon'>&#xe65b;</i>"
                +       "</span>"
                +       "<input id='numchange' name='hayden' type='text' value='1'>"
                +       "<span id='numplus'>"
                +       "<i class='iconfont plicon'>&#xe639;</i>"
                +       "</span>"
                +       "<div class='clear'>"
                +       "</div>"
                +       "</div>"
                +       "<div class='button'>"
                +       "<a href='javascript:;' id='buynow' data-Capacity='"+ info.showCapacity +"' data-uuid='"+ info.productUuid +"' >立即购买</a>"
                    //+       "<img  src='" + info.pic +"'>"
                    //+       "<a href='#' class='addcar' id='plusmarket' onclick='cart(this)' data-Capacity='"+ info.showCapacity +"' data-uuid='"+ info.productUuid +"'>"
                +       "<a href='javascript:;' class='addcar' id='plusmarket' data-Capacity='"+ info.showCapacity +"' data-uuid='"+ info.productUuid +"'>"
                +       "<i class='iconfont marketicon'>&#xe600;</i>加入购物车</a>"
                +       "</div>";

        }



        prodetail = prodetail1 + prosize + prodetail2;

        $(".headRight").append(prodetail);




        $("input[name='hayden']").keyup(function(){
            $(this).val($(this).val().replace(/\D|^0/g,''));
            if($(this).val() >= "100"){
                $(this).val(100);
            }
        }).bind("paste",function(){
            $(this).val($(this).val().replace(/\D|^0/g,''));

        }).css("ime-mode", "disabled");






        //购物车飞入效果
        $(".addcar").click(function(event){
            var start = $("#plusmarket");
            var target = $(".shop").offset();
            var Capacity1 = $("#buynow").attr("data-Capacity");
            var num1 = parseInt($("#numchange").val());

            if(num1 > Capacity1){

                //$("#numchange").val("100");
                error("商品库存不足");
                return false;
            }else if($("#numchange").val() == ""){
                error("请输入购买数量");
                return false;
            }
            else{
                var addcar = $(this);
                var img = $(".img").attr('src');
                var flyer = $('<img class="u-flyer" src="'+img+'">');
                flyer.fly({
                    start: {
                        left: start.offset().left , //开始位置（必填）#fly元素会被设置成position: fixed
                        top: start.offset().top-10 //开始位置（必填）
                    },
                    end: {
                        left: target.left + 60, //结束位置（必填）
                        top: target.top + 10, //结束位置（必填）
                        width: 20, //结束时宽度
                        height: 20 //结束时高度
                    },
                    onEnd: function(){ //结束回调
                        flyer.remove();
                        //修改购物车数量,延迟半秒钟修改
                        cart(this,500)
                    }
                });
            }

        });


        //数量加减
        $("#numminus").click(function(){

            var num1 = parseInt($("#numchange").val());
            if(num1<=1){
                error("本商品1件起售");
                return false;
            }else{
                num1 --;
                $("#numchange").val(num1);
            }

        });

        $("#numplus").click(function(){
            var num1 = parseInt($("#numchange").val());
            if(num1 >= info.showCapacity){
                error("数量已达库存上限");
                return false;
            }else if( num1 == "100"){
                error("单品已达上限");
                return false;
            }
            else{
                num1 ++;
                $("#numchange").val(num1);
            }

        });


        //立即购买
        $("#buynow").click(function(){
            var procode = $("#buynow").attr("data-uuid");
            var Capacity = $("#buynow").attr("data-Capacity");
            var num = parseInt($("#numchange").val());

            if(num > Capacity){
                error("商品库存不足");
                return false;
            }else{
                window.location.href= buy_url + "?productUuid=" + procode + "&showCapacity=" + Capacity + "&capacity=" + num;
            }



        });



        //大家都在看&人气单品
        var psee = "";
        var singlepro = "";
        $.each(info.productCfgList,function(i,item){

            if( item.type == 8 ){

                psee += "<li class='propic' data-id='"+ item.productUuid +"'>"
                    +  "<span>"
                    +  "<img src='"+ item.picUrl +"'>"
                    +  "</span>"
                    +  "<p class='rolltitle'>"+ item.name +"</p>"
                    +  "<p class='rollprice'>￥"+ item.price.toFixed(2) +"</p>"
                    +  "</li>";
            }
            else if( item.type == 9 ){

                singlepro += "<li class='rep' data-id='"+ item.productUuid +"'>"
                    +       "<img src='"+ item.picUrl +"'>"
                    +       "<div class='blackword'>"+ item.name +"</div>"
                    +       "</li>";

            }

        });
        $(".proclass").append(psee);
        $(".recom").append(singlepro);


        $(".propic").click(function(){
            var pid= $(this).attr("data-id");
            window.open(pro_url + pid);
        });

        $(".rep").click(function(){
            var pid= $(this).attr("data-id");
            window.open(pro_url + pid);
        });







        //商品详细批次信息等
        dmessage = "<ul class='jieshao'>"
            +      "<li>生产许可证编号："+ info.license +"</li>"
            +      "<li>产品标准号："+ info.standardNo +"</li>"
            +      "<li>品牌："+ info.brand +"</li>"
            +      "</ul>"
            +      "<ul class='jieshao'>"
            +      "<li>保质期："+ info.releaseDate +"</li>"
            +      "<li>产地："+ info.provenance +"</li>"
            +      "<li>净含量："+ info.netContent +"</li>"
            +      "</ul>"
            +      "<ul class='jieshao'>"
            +      "<li>条形码："+ info.barcode +"</li>"
            +      "<li>系列："+ info.series +"</li>"
            +      "<li>存储方式："+ info.storage +"</li>"
            +      "</ul>";

        $(".test_tab_content").append(dmessage);

        //商品详情图组
        picclass = "<p>"+ info.description +"</p>"
                +  "<p id='ptarget'>"
                +  "<img src='http://bdhec.oss-cn-hangzhou.aliyuncs.com/note/nq.jpg'>"
                +  "</p>";
        $(".detailimg").append(picclass);


        $("#testTabRadio2").click(function(){
            $("html,body").animate({scrollTop:$("#ptarget").offset().top},1000);
        });


    }




});

