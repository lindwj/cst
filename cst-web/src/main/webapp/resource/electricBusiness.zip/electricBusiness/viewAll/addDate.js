$(function () {




    //默认显示第一页的数据
    var localObj = window.location;
    var contextPath = localObj.pathname.split("/")[1];
    var basePath = localObj.protocol+"//"+localObj.host+"/"+contextPath;
    var server_context=basePath;

    //获取登录后进入的订单管理的链接
    var ajaxURL =  product_url;
    $.ajax({
        type: 'POST',
        url: ajaxURL,
        dataType : "json" ,
        data: {},

        success:
            function(data,textStatus){

                //显示订单管理第一页数据
                getOrderList(data.pList);


            },
        error:
            function(data,textStatus){


            }

    });





    //解析json数据，页面显示
    function getOrderList(info) {



        var product1 = "";
        var product2 = "";
        var product1_else = "";
        var product2_else = "";
        var product2_else1 = "";
        var menu = "";


        $.each(info, function (i, item) {


            if( i == 0){
                menu="";
            }else{
                menu += "<li>"
                    +  "<a class='view_all' data-id='"+i+"'>"+ item.parameterName +"</a>"
                    +  "</li>";
            }


            var ordercode=window.location.href.split("=")[1];

            if(i==ordercode){

                product1_else = "";
                product2_else1 = "";
                product2_else = "";

                product1 = "<div class='floor1'>"
                    + "<div class='title1'>"
                    + "<h1>" + item.parameterName + "</h1>"
                    + "</div>"
                    + "<div class='clear'>"
                    + "</div>"
                    + "<ul class='lfloor1'>";

                if (item.productList.length > 0) {

                    $.each(item.productList, function (n, ntem) {
                        var price = ntem.price;

                        if( price == 100000){
                            ntem.price = "即将上线";
                            if (n%4 == 0) {
                                product1_else = "<li class='product8' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    + "<img src=\"" + ntem.pic + "\"/>"
                                    + "</div>"
                                    + "<a href='#'>" + ntem.name + "</a>"
                                    + "<p>" + ntem.price + "</p>"
                                    + "</li>"

                            }
                            else {

                                product1_else = "<li class='product7' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    + "<img src=\"" + ntem.pic + "\"/>"
                                    + "</div>"
                                    + "<a href='#'>" + ntem.name + "</a>"
                                    + "<p>" + ntem.price + "</p>"
                                    + "</li>";

                            }
                        }else{
                            ntem.price = ntem.price;
                            if (n%4 == 0) {
                                product1_else = "<li class='product8' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    + "<img src=\"" + ntem.pic + "\"/>"
                                    + "</div>"
                                    + "<a href='#'>" + ntem.name + "</a>"
                                    + "<p>￥" + ntem.price.toFixed(2) + "</p>"
                                    + "</li>"

                            }
                            else {

                                product1_else = "<li class='product7' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    + "<img src=\"" + ntem.pic + "\"/>"
                                    + "</div>"
                                    + "<a href='#'>" + ntem.name + "</a>"
                                    + "<p>￥" + ntem.price.toFixed(2) + "</p>"
                                    + "</li>";

                            }
                        }


                            product2_else=product2_else+product1_else;
                            product1_else="";
                    });


                    product2_else1 = product2_else + "</ul>" + "<div class='clear'>" + "</div>" + "</div>";

                    product2 += product1 + product2_else1;


                }
            }

        });

        $(".allproduct").append(product2);
        $(".menu1").append(menu);



        $(".view_all").click(function(){
            $(this).addClass("menu_colorchange");
            var code = $(this).attr("data-id");
            window.open('viewAll.html' + '?code=' + code);

        });


        $(".product7").click(function(){
            var pid= $(this).attr("data-id");
            window.open(pro_url + pid);
        });
        $(".product8").click(function(){
            var pid= $(this).attr("data-id");
            window.open(pro_url + pid);
        });


    }


});