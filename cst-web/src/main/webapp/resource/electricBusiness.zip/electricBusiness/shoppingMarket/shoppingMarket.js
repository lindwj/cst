$(function(){


    $.ajax({
        type:'post',
        url:marketpro_url,
        dataType:'json',
        data:{},
        success:
            function(data){
                getmarket(data.products);
            },
        error:
            function(data){

            }

    });
    var footer = "";
    function getmarket(info){

        if(info==null){
            $("tbody").append("<p class='nullstyle'><i class='iconfont nullicon'>&#xe62a;</i><br>购物车还是空滴</p><a class='goshop' href='"+index_url+"'>去逛逛 >></a>");
        }else{
            var pro = "";

            var nn = info.length;
            //商品列表
            $.each(info,function(i,item){



                if(nn==i+1){
                    pro += "<tr>"
                        + "<th class='col1'>"
                        + "<input class='check' type='checkbox' name='check' data-uuid='"+ item.productUuid +"'>"
                        + "<img class='picture' src='"+ item.pic +"' data-id='"+ item.productUuid +"'>"
                        + "</th>"
                        + "<th class='col2'><span class='plian' data-id='"+ item.productUuid +"'>"+ item.name +"</span></th>"
                        + "<th class='col3'>￥<span class='price1'>"+ item.price.toFixed(2) +"</span></th>"
                        + "<th class='col4'>"
                        + "<div class='number'>"
                        + "<span class='numminus'>"
                        + "<i class='iconfont plicon'>&#xe65b;</i>"
                        + "</span>"
                        + "<input class='numchange' name='yogurt' name='hayden' type='text' value='"+ item.capacity +"'>"
                        + "<span class='numplus'>"
                        + "<i class='iconfont plicon'>&#xe639;</i>"
                        + "</span>"
                        + "<div class='clear'>"
                        + "</div>"
                        + "</div>"
                        + "</th>"
                        + "<th class='col5' style='color:#d7282d ;'>￥<span class='price2'>"+ (item.price*item.capacity).toFixed(2) +"</span></th>"
                        + "<th class='col6'><i class='iconfont deleicon' data-uuid='"+ item.productUuid +"'>&#xe686;</i></th>"
                        + "</tr>";
                }else{
                    pro += "<tr>"
                        + "<th class='col1 border'>"
                        + "<input class='check' type='checkbox' name='check' data-uuid='"+ item.productUuid +"'>"
                        + "<img class='picture' src='"+ item.pic +"' data-id='"+ item.productUuid +"'>"
                        + "</th>"
                        + "<th class='col2 border'><span class='plian' data-id='"+ item.productUuid +"'>"+ item.name +"</span></th>"
                        + "<th class='col3 border'>￥<span class='price1'>"+ item.price.toFixed(2) +"</span></th>"
                        + "<th class='col4 border'>"
                        + "<div class='number'>"
                        + "<span class='numminus'>"
                        + "<i class='iconfont plicon'>&#xe65b;</i>"
                        + "</span>"
                        + "<input class='numchange' name='yogurt' name='hayden' type='text' value='"+ item.capacity +"'>"
                        + "<span class='numplus'>"
                        + "<i class='iconfont plicon'>&#xe639;</i>"
                        + "</span>"
                        + "<div class='clear'>"
                        + "</div>"
                        + "</div>"
                        + "</th>"
                        + "<th class='col5 border' style='color:#d7282d ;'>￥<span class='price2'>"+ (item.price*item.capacity).toFixed(2) +"</span></th>"
                        + "<th class='col6 border'><i class='iconfont deleicon' data-uuid='"+ item.productUuid +"'>&#xe686;</i></th>"
                        + "</tr>";
                }

            });

            $("tbody").append(pro);

        }


        footer = "<tr>"
            +    "<th class='col7'>"
            +    "<input type='checkbox' class='allcheck' name='allcheck' id='allcheck'>"
            +    "<span class='all' id='all'>全选</span>"
            +    "<span class='pick'>已选（<span class='checknum'>0</span>）</span>"
            +    "</th>"
            +    "<th class='col8' id='delall'>批量删除</th>"
            +    "<th class='col9' colspan='4'>"
            +    "<button id='orderUp'>下单</button>"
            +    "<div class='price'>"
            +    "<p class='p1'>应付总额 :</p>"
            +    "<p class='p2'>￥<span class='totalprice'>0.00</span></p>"
            +    "<br>"
            +    "<p class='p3'>不含运费</p>"
            +    "</div>"
            +    "</th>"
            +    "</tr>";
        $("tfoot").append(footer);

        //正则校验输入框里不允许有中文、英文、字符并且最大数字为100
        $("input[name='yogurt']").keyup(function(){
            $(this).val($(this).val().replace(/\D|^0/g,''));
            //var capacity = $(this).attr('data-capacity');
            if($(this).val() > 100){
                $(this).val(100);
            }
            //else if($(this).val() > capacity){
            //    error("数量已达库存上限");
            //    $(this).val(capacity);
            //    return false;
            //}
        }).bind("paste",function(){
            $(this).val($(this).val().replace(/\D|^0/g,''));

        }).css("ime-mode", "disabled");


        //数量减少
        var num1 = 0;
        var myTimeout ="";
        $(".numminus").click(function(){

            //clearTimeout(myTimeout);
            //myTimeout = setTimeout(function() {
            //    $(".numminus").click();
            //}, 5000);
            num1 = parseFloat($(this).next().val());
            var price1 = $(this).parent().parent().prev().children().text();
            var price2 = $(this).parent().parent().next().children().text();
            num1 = num1 - 1;
            if(num1<1){
                error("本商品1件起售");
                return false;
            }else{
                $(this).next().val(num1);
                price2 = num1*price1;
                $(this).parent().parent().next().children().text(price2.toFixed(2));

            }

            var num = 0;
            var priceall = 0;
            if($("input[name=check]").is(':checked')){

                $("input[name=check]").each(function(i,element){

                    if($("input[name=check]").eq(i).is(':checked')){
                        num = parseInt(num) + parseInt($(".numchange").eq(i).val());
                        priceall = parseFloat(priceall) + parseFloat($(".price2").eq(i).text());
                    }

                });
                $(".checknum").text(num);
                $(".totalprice").text(priceall.toFixed(2));
                num = "";
                priceall = "";
            }else{
                $(".totalprice").text("0.00");
            }



        });
         //数量增加
        var num2 = 0;
        var price4 = 0;
        $(".numplus").click(function(){
            num2 = parseFloat($(this).prev().val());
            //var capacity = $(this).attr("data-capacity");
            var price3 = $(this).parent().parent().prev().children().text();

            num2 = num2 + 1;

            //if(num2>capacity){
            //    error("数量已达库存上限");
            //    return false;
            //}
            //else{
            $(this).prev("input").val(num2);
            price4 = num2*price3;
            $(this).parent().parent().next().children().text(price4.toFixed(2));
            //}
            var num = 0;
            var priceall = 0;
            if($("input[name=check]").is(':checked')){

                $("input[name=check]").each(function(i,element){

                    if($("input[name=check]").eq(i).is(':checked')){
                        num = parseInt(num) + parseInt($(".numchange").eq(i).val());
                        priceall = parseFloat(priceall) + parseFloat($(".price2").eq(i).text());
                    }

                });
                $(".checknum").text(num);
                $(".totalprice").text(priceall.toFixed(2));
                num = "";
                priceall = "";
            }else{
                $(".totalprice").text("0.00");
            }

        });


        //checkbox选中
        $(".check").click(function(){

            var num = 0;
            var priceall = 0;
            if($("input[name=check]").is(':checked')){

                $("#all").hide();
                $(".pick").show();

                $("input[name=check]").each(function(i,element){

                    if($("input[name=check]").eq(i).is(':checked')){
                        num = parseInt(num) + parseInt($(".numchange").eq(i).val());
                        priceall = parseFloat(priceall) + parseFloat($(".price2").eq(i).text());
                    }else{
                        $("input[name=checkall]").attr("checked",false);
                        $("input[name=allcheck]").attr("checked",false);
                    }

                });
                $(".checknum").text(num);
                $(".totalprice").text(priceall.toFixed(2));
                num = "";
                priceall = "";
            }else{
                $("input[name=checkall]").attr("checked",false);
                $("input[name=allcheck]").attr("checked",false);
                $(".pick").hide();
                $("#all").show();
                $(".totalprice").text("0.00");
            }
            if($("input[name=check]:checked").length==$("input[name=check]").length){
                $("input[name=checkall]").attr("checked",true);
                $("input[name=allcheck]").attr("checked",true);
            }
        });
        //上面的全选
        $("#checkall").click(function(){
            var numall = 0;
            var priceall = 0;
            if($("input[name=checkall]").is(':checked')){
                $("input[name=allcheck]").attr("checked",true);
                $("input[name=check]").attr("checked",true);
                $("#all").hide();
                $(".pick").show();
                $("input[name=check]").each(function(i,element){

                    if($("input[name=check]").eq(i).is(':checked')){
                        numall = parseInt(numall) + parseInt($(".numchange").eq(i).val());
                        priceall = parseFloat(priceall) + parseFloat($(".price2").eq(i).text());
                    }

                });
                $(".checknum").text(numall);
                $(".totalprice").text(priceall.toFixed(2));
                numall = "";
                priceall = "";
            }else{
                $("input[name=allcheck]").attr("checked",false);
                $("input[name=check]").attr("checked",false);
                $(".pick").hide();
                $("#all").show();
                $(".totalprice").text("0.00");
            }

        });
        //下面的全选
        $("#allcheck").click(function(){

            var numall = 0;
            var priceall = 0;
            if($("input[name=allcheck]").is(':checked')){
                $("input[name=checkall]").attr("checked",true);
                $("input[name=check]").attr("checked",true);
                $("#all").hide();
                $(".pick").show();
                $("input[name=check]").each(function(i,element){

                    if($("input[name=check]").eq(i).is(':checked')){
                        numall = parseInt(numall) + parseInt($(".numchange").eq(i).val());
                        priceall = parseFloat(priceall) + parseFloat($(".price2").eq(i).text());
                    }

                });
                $(".checknum").text(numall);
                $(".totalprice").text(priceall.toFixed(2));
                numall = "";
                priceall = "";

            }else{
                $("input[name=checkall]").attr("checked",false);
                $("input[name=check]").attr("checked",false);
                $(".pick").hide();
                $("#all").show();
                $(".totalprice").text("0.00");
            }

        });


        //单个商品删除
        $(".deleicon").click(function(){

            var del = $(this).attr("data-uuid");
            $(".black_box").fadeIn(500);
            $("#delbtn").attr("data-del", del) ;

        });
        //取消删除
        $("#cancle").click(function(){
            $(".black_box").fadeOut(500);
        });
        //确认删除
        $("#delbtn").click(function(){

            var del = $(this).attr("data-del");
            $.ajax({
                type: 'POST',
                url: delet_url,
                dataType : "json" ,
                data: {
                    productUuid:del
                },

                success:
                    function(data){


                        window.location.reload();



                    },
                error:
                    function(data){

                    }

            });
        });


        //批量删除
        $("#delall").click(function(){
            if($("input[name=check]").is(':checked')){
                $(".black_box1").fadeIn(500);
            }else{
                error("至少选择一个商品");
                return false;
            }
        });
        //取消删除
        $("#cancle1").click(function(){
            $(".black_box1").fadeOut(500);
        });
        //确认删除
        $("#delbtn1").click(function(){

            var x=0;
            var ajaxData = "";
            $("input[name=check]").each(function(i,element){


                if($("input[name=check]").eq(i).is(':checked')){

                    $("input[name=check]").eq(i).attr("data-code",1);
                    var uuid = $("input[name=check]").eq(i).attr("data-uuid");
                    var code = $("input[name=check]").eq(i).attr("data-code");
                    var number = $(".numchange").eq(i).val();


                    if(number == ""){
                        error("请输入购买数量");
                        return false;
                    }else{
                        ajaxData = ajaxData + "&ordersDetailList[" + x +"].productUuid="+ uuid +"&ordersDetailList[" + x +"].code="+ code+"&ordersDetailList[" + x +"].capacity="+ number +"";
                        x=x+1;
                    }

                }else{
                    $("input[name=check]").attr("data-code",0);
                }

            });


            $.ajax({
                type: 'POST',
                url: delall_url,
                dataType : "json" ,
                data: ajaxData ,

                success:
                    function(data){

                        window.location.reload();

                    },
                error:
                    function(data){

                    }

            });

        });


        //商品链接
        $(".plian").click(function(){
            var pid= $(this).attr("data-id");
            window.open(pro_url + pid);
        });
        $(".picture").click(function(){
            var pid= $(this).attr("data-id");
            window.open(pro_url + pid);
        });
        //下单
        $("#orderUp").click(function(){

            var x=0;
            var ajaxData = "";
            $("input[name=check]").each(function(i,element){


                if($("input[name=check]").eq(i).is(':checked')){

                    $("input[name=check]").eq(i).attr("data-code",1);
                    var uuid = $("input[name=check]").eq(i).attr("data-uuid");
                    var code = $("input[name=check]").eq(i).attr("data-code");
                    var number = $(".numchange").eq(i).val();


                    if(number == ""){
                        error("请输入购买数量");
                        return false;
                    }else{
                        ajaxData = ajaxData + "&ordersDetailList[" + x +"].productUuid="+ uuid +"&ordersDetailList[" + x +"].code="+ code+"&ordersDetailList[" + x +"].capacity="+ number +"";
                        x=x+1;
                    }

                }else{
                    $("input[name=check]").attr("data-code",0);
                }

            });
            if(ajaxData == ""){
                error("至少选择一个商品");
                return false;
            }else{
                $.ajax({
                    type: 'POST',
                    url: orderUp_url,
                    dataType : "json" ,
                    data: ajaxData ,

                    success:
                        function(data){

                            if(data.status==1){
                                error("请先登录后再访问");
                                window.location.href= login_url;
                            }else{
                                window.location.href= orderUp_path + "?" + ajaxData;
                            }


                        },
                    error:
                        function(data){

                        }

                });
            }

        })

    }



});