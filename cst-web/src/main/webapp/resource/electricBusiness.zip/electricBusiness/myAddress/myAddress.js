
function onSelectChange(obj,toSelId){
    setSelect(obj.value,toSelId);
}
function setSelect(fromSelVal,toSelId){
    document.getElementById(toSelId).innerHTML="";
    jQuery.ajax({
        url: select_url,
        cache : false,
        data : "parent=" + fromSelVal,
        success : function(data) {
            createSelectObj(data, toSelId);
        }
    });
}
function createSelectObj(data, toSelId) {
    var arr = JSON.parse(data);
    if (arr != null && arr.length > 0) {

        if (toSelId == 'selstreet') {
            $("#"+toSelId).show();
        }


        var obj = document.getElementById(toSelId);
        obj.innerHTML = "";
        var nullOp = document.createElement("option");
        nullOp.setAttribute("value", "");
        nullOp.appendChild(document.createTextNode("请选择"));
        obj.appendChild(nullOp);
        for ( var o in arr) {
            var op = document.createElement("option");
            op.setAttribute("value", arr[o].id);
            //op.text=arr[o].name;//这一句在ie下不起作用，用下面这一句或者innerHTML
            if (toSelId == 'selprovince') {
                op
                    .appendChild(document
                        .createTextNode(arr[o].province));
            } else if (toSelId == 'selcity') {
                op.appendChild(document.createTextNode(arr[o].city));
            } else if (toSelId == 'seldistrict') {
                op
                    .appendChild(document
                        .createTextNode(arr[o].district));
            } else if (toSelId == 'selstreet') {
                op.appendChild(document.createTextNode(arr[o].street));
            }
            obj.appendChild(op);
        }
    }else{
        if (toSelId == 'selstreet') {
            var obj = document.getElementById(toSelId);
            $("#"+toSelId).hide();
        }
    }
}
setSelect('1', 'selprovince');
$(function(){

    $.ajax({
        type:'post',
        url:alladdress_url,
        dataType:'json',
        data:{},
        success:
            function(data){
                getaddress(data);
                $("#allpage").text(data.page.totalPage);
                $("#curpage").text(data.page.currentPage);
            },
        error:
            function(data){
                error("请先登录后再访问！");
                window.location.href= login_url;
            }
    });



    //下一页
    $("#nextmove").click(function(){



        //获取账号和密码
        //查询条件
        var curPage = $("#curpage").html() - 0 + 1;
        var allPage = $("#allpage").html();

        if(curPage > allPage){
           error("已经是最后一页了");
            return false;
        }
        $(".adds").empty();

        $.ajax({
            type: 'POST',
            url: alladdress_url,
            dataType : "json" ,
            data:
            {
                'page.currentPage':curPage,
                'page.totalPage':allPage

            },

            success:
                function(data,textStatus){


                    getaddress(data);
                    $("#allpage").text(data.page.totalPage);
                    $("#curpage").text(data.page.currentPage);


                },
            error:
                function(data,textStatus){
                    //alert("success:" + data + "," + textStatus);
                    alert("服务器异常，请稍后再试");
                }

        });

    });
    //上一页
    $("#prevmove").click(function(){





        //获取账号和密码
        //查询条件
        var curPage = $("#curpage").html() - 0 - 1;
        var allPage = $("#allpage").html();
        if(curPage < 1){
            error("已经第一页了");
            return false;
        }
        $(".adds").empty();
        $.ajax({
            type: 'POST',
            url: alladdress_url,
            dataType : "json" ,
            data:
            {
                'page.currentPage':curPage,
                'page.totalPage':allPage

            },

            success:
                function(data,textStatus){


                    getaddress(data);
                    $("#allpage").text(data.page.totalPage);
                    $("#curpage").text(data.page.currentPage);


                },
            error:
                function(data,textStatus){
                    //alert("success:" + data + "," + textStatus);
                    alert("服务器异常，请稍后再试");
                }

        });

    });
    //下两页
    $("#jump2").click(function(){



        //获取账号和密码
        //查询条件
        var curPage = $("#curpage").html() - 0 + 1;
        var allPage = $("#allpage").html();

        if(curPage > allPage){
           error("已经是最后一页了");
            return false;
        }
        $(".adds").empty();

        $.ajax({
            type: 'POST',
            url: alladdress_url,
            dataType : "json" ,
            data:
            {
                'page.currentPage':curPage,
                'page.totalPage':allPage

            },

            success:
                function(data,textStatus){


                    getaddress(data);
                    $("#allpage").text(data.page.totalPage);
                    $("#curpage").text(data.page.currentPage);


                },
            error:
                function(data,textStatus){
                    //alert("success:" + data + "," + textStatus);
                    alert("服务器异常，请稍后再试");
                }

        });

    });
    //上yi页
    $("#jump1").click(function(){





        //获取账号和密码
        //查询条件
        var curPage = $("#curpage").html() - 0 - 1;
        var allPage = $("#allpage").html();
        if(curPage < 1){
            error("已经第一页了");
            return false;
        }
        $(".adds").empty();
        $.ajax({
            type: 'POST',
            url: alladdress_url,
            dataType : "json" ,
            data:
            {
                'page.currentPage':curPage,
                'page.totalPage':allPage

            },

            success:
                function(data,textStatus){


                    getaddress(data);
                    $("#allpage").text(data.page.totalPage);
                    $("#curpage").text(data.page.currentPage);


                },
            error:
                function(data,textStatus){
                    //alert("success:" + data + "," + textStatus);
                    alert("服务器异常，请稍后再试");
                }

        });

    });
    //跳转到指定页
    $("#goBtn").click(function(){


        //获取账号和密码
        //查询条件
        var allPage = $("#allpage").html();
        var gotoPage = $("#gotoPageNo").val().trim();
        if(gotoPage < 1){
            error("页数至少从1开始");
            return false;
        }else if(gotoPage>allPage){
            error("一共只有"+allPage+"页");
            return false;
        }
        $(".adds").empty();

        $.ajax({
            type: 'POST',
            url: alladdress_url,
            dataType : "json" ,
            data:
            {
                'page.currentPage':gotoPage,
                'page.totalPage':allPage

            },

            success:
                function(data,textStatus){


                    getaddress(data);
                    $("#allpage").text(data.page.totalPage);
                    $("#curpage").text(data.page.currentPage);


                },
            error:
                function(data,textStatus){
                    //alert("success:" + data + "," + textStatus);
                    alert("服务器异常，请稍后再试");
                }

        });

    });





    function getaddress(info){

        var addresslist = "";
        var defa = "";
        var footer = "";
        var street = "";
        var address = "";
        if( info.goodsAddressList ==""){

            $(".adds").append("<tr class='nullw'><th colspan='7' style='border-bottom:1px solid #ddd;font-size: 15px;'>当前地址为空，请先添加地址</th></tr>");

        }else{
            $.each(info.goodsAddressList,function(i,item){

                if(item.streetstr==null){
                    street = "";
                }else{
                    street = item.streetstr;
                }
                addresslist = "<tr id='"+ item.goodsAddressUuid +"'>"
                    +         "<th class='col1'>"+item.name+"</th>"
                    +         "<th class='col2'><span class='addressDetail1'>"+item.provincestr+"</span><span class='addressDetail2'>"+item.citystr+"</span><span class='addressDetail3'>"+item.districtstr+"</span><span class='addressDetail4'>"+street+"</span><span class='addressDetail5'>"+item.address+"</span></th>"
                    +         "<th class='col3'>"+item.mobile+"</th>"
                    +         "<th class='col4'>"
                    +         "<div class='edit'>"
                    +         "<p class='address_change' data-uuid='"+ item.goodsAddressUuid +"' data-default='"+ item.isDefault +"'>编辑</p>"
                    +         "<p class='address_delete' data-uuid='"+ item.goodsAddressUuid +"'>删除</p>";

                if(item.isDefault == 1){
                    defa = "<a class='same pay' data-uuid='"+ item.goodsAddressUuid +"' data-default='"+ item.isDefault +"'>默认地址</a>";
                }else{
                    defa = "<a class='same def' data-uuid='"+ item.goodsAddressUuid +"' data-default='"+ item.isDefault +"'>设为默认地址</a>";
                }

                footer = "</div>"
                    +         "</th>"
                    +         "</tr>";
                address += addresslist + defa + footer;
            });
            $(".adds").append(address);


        }
        //新建地址
        $(".new").click(function(){
            $(".name").val("");
            $(".tele").val("");
            $(".mobil").val("");
            $(".adddetail").val("");
            $("#selprovince").val("");
            $("#selcity").val("");
            $("#seldistrict").val("");
            $("#selstreet").val("");
            $("input[name=checked]").attr("checked",false);
            $(".hide_box1").fadeIn();
        });
        //取消
        $("#back").click(function(){
            $("#ok").attr("data-uuid","");
            $(".hide_box1").fadeOut();
        });
        //编辑地址
        $(".address_change").click(function(){

            $(".name").val("");
            $(".tele").val("");
            $(".mobil").val("");
            $(".adddetail").val("");
            $("#selprovince").val("");
            $("#selcity").val("");
            $("#seldistrict").val("");
            $("#selstreet").val("");
            $("input[name=checked]").attr("checked",false);

            var uid = $(this).attr("data-uuid");
            var dfa = $(this).attr("data-default");

            $.ajax({
                type: 'POST',
                url:search_url,
                dataType :'json',
                data:{
                    goodsAddressUuid:uid
                },
                success:
                    function(data){


                        var n= data.name;
                        var m= data.mobile;
                        var t= data.telephone;
                        var a= data.address;
                        var p= data.province;
                        var c= data.city;
                        var d= data.district;
                        var s= data.street;




                        function onSelectChange(obj,toSelId){
                            setSelect(obj.value,toSelId);
                        }
                        function setSelect(fromSelVal,toSelId){
                            //alert(document.getElementById("province").selectedIndex);
                            document.getElementById(toSelId).innerHTML="";
                            jQuery.ajax({
                                url: select_url,
                                cache : false,
                                data : "parent=" + fromSelVal,
                                success : function(data) {
                                    createSelectObj(data, toSelId);
                                }
                            });
                        }
                        function createSelectObj(data, toSelId) {
                            var arr = JSON.parse(data);
                            if (arr != null && arr.length > 0) {

                                if (toSelId == 'selstreet') {
                                    $("#"+toSelId).show();
                                }


                                var obj = document.getElementById(toSelId);
                                obj.innerHTML = "";
                                var nullOp = document.createElement("option");
                                nullOp.setAttribute("value", "");
                                nullOp.appendChild(document.createTextNode("请选择"));
                                obj.appendChild(nullOp);
                                for ( var o in arr) {
                                    var op = document.createElement("option");

                                    op.setAttribute("value", arr[o].id);
                                    //op.text=arr[o].name;//这一句在ie下不起作用，用下面这一句或者innerHTML
                                    if (toSelId == 'selprovince') {
                                        if(arr[o].id==p){
                                            op.setAttribute("selected", 'selected');
                                        }
                                        op
                                            .appendChild(document
                                                .createTextNode(arr[o].province));
                                    } else if (toSelId == 'selcity') {
                                        if(arr[o].id==c){
                                            op.setAttribute("selected", 'selected');
                                        }
                                        op.appendChild(document.createTextNode(arr[o].city));
                                    } else if (toSelId == 'seldistrict') {
                                        if(arr[o].id==d){
                                            op.setAttribute("selected", 'selected');
                                        }
                                        op
                                            .appendChild(document
                                                .createTextNode(arr[o].district));
                                    }else if (toSelId == 'selstreet') {
                                        if(arr[o].id==s){
                                            op.setAttribute("selected", 'selected');
                                        }
                                        op
                                            .appendChild(document
                                                .createTextNode(arr[o].street));
                                    }
                                    obj.appendChild(op);
                                }
                            }else{
                                if (toSelId == 'selstreet') {
                                    var obj = document.getElementById(toSelId);
                                    $("#"+toSelId).hide();
                                }
                            }
                        }
                        setSelect('1', 'selprovince');
                        setSelect(p, 'selcity');
                        setSelect(c, 'seldistrict');

                        if(s!=null && s > 0){
                            setSelect(d, 'selstreet');
                        }else if(s==""){
                            $("#selstreet").hide();
                        }
                        $(".name").val(n);
                        $(".tele").val(m);
                        $(".mobil").val(t);
                        $(".adddetail").val(a);
                        $("#selprovince").val(p);
                        $("#selcity").val(c);
                        $("#seldistrict").val(d);
                        $("#selstreet").val(s);
                        $("#ok").attr("data-uuid",uid);
                        if(dfa == 1){
                            $("input[name=checked]").attr("checked",true);
                        }else{
                            $("input[name=checked]").attr("checked",false);
                        }

                        $(".hide_box1").fadeIn();
                    },
                error:
                    function(data,textStatus){

                    }
            });

        });

        //确认添加
        $("#ok").click(function(){

            $(".nullw").remove();
            var add_address = "";
            var pname = $(".name").val();
            var tele = $(".tele").val();
            var mobile1 = $(".mobil").val();
            var detail = $(".adddetail").val();
            var province = $("#selprovince").val();
            var city = $("#selcity").val();
            var district = $("#seldistrict").val();
            var street = $("#selstreet").val();


            var uid = $(this).attr("data-uuid");

            if(street == null){
                street = "";
            }

            var province1 = $("#selprovince").find("option:selected").text();
            var city1 = $("#selcity").find("option:selected").text();
            var district1 = $("#seldistrict").find("option:selected").text();
            var street1 = $("#selstreet").find("option:selected").text();
            if(street1 == null){
                street1 = "";
            }

            if($("input[name=checked]").is(':checked')){
                $(this).attr("data-default","1");
            }else{
                $(this).attr("data-default","0");
            }

            var defa = $(this).attr("data-default");


            var reg = /(1[3-9]\d{9}$)/;


            if(!reg.test(tele)){
                error("请输入有效的11位手机号");
                return false;
            }
            if(pname == ""){
                error("请添加收货人姓名");
                return false;
            }else if(tele == ""){
                error("请添加收货人手机号");
                return false;
            }else if(detail == ""){
                error("请添加收货人地址");
                return false;
            }
            else{

                if(uid != ""&& uid!=null && uid!=undefined){

                    $.ajax({
                        type: 'POST',
                        url:addressEdit_url,
                        dataType : "json" ,
                        data:{
                            goodsAddressUuid:uid,
                            province:province,
                            city:city,
                            district:district,
                            street:street,
                            address:detail,
                            name:pname,
                            mobile:tele,
                            isDefault:defa,
                            telephone:mobile1
                        },
                        success:
                            function(data){
                                var id = "#"+uid;
                                if(data==101){
                                    error("每项必填");
                                    return false;
                                }else if(data==100){
                                    error("当前地址已存在");
                                    return false;
                                }else if(defa == 1){

                                    $(id).children("th").eq(0).text(pname);
                                    $(id).children("th").eq(1).children("span").eq(0).text(province1);
                                    $(id).children("th").eq(1).children("span").eq(1).text(city1);
                                    $(id).children("th").eq(1).children("span").eq(2).text(district1);
                                    $(id).children("th").eq(1).children("span").eq(3).text(street1);
                                    $(id).children("th").eq(1).children("span").eq(4).text(detail);
                                    $(id).children("th").eq(2).text(tele);
                                    $(".same").removeClass("pay").addClass("def").attr("data-default","0").text("设为默认地址");
                                    $(id).children("th").eq(3).children("div").children().eq(0).attr("data-default","1");
                                    $(id).children("th").eq(3).children("div").children().eq(2).removeClass("def").addClass("pay").attr("data-default","1").text("默认地址");
                                    $(".hide_box1").fadeOut();
                                }else if(defa ==0){

                                    $(id).children("th").eq(0).text(pname);
                                    $(id).children("th").eq(1).children("span").eq(0).text(province1);
                                    $(id).children("th").eq(1).children("span").eq(1).text(city1);
                                    $(id).children("th").eq(1).children("span").eq(2).text(district1);
                                    $(id).children("th").eq(1).children("span").eq(3).text(street1);
                                    $(id).children("th").eq(1).children("span").eq(4).text(detail);
                                    $(id).children("th").eq(2).text(tele);
                                    $(id).children("th").eq(3).children("div").children().eq(0).attr("data-default","0");
                                    $(id).children("th").eq(3).children("div").children().eq(2).removeClass("pay").addClass("def").attr("data-default","0").text("设为默认地址");
                                    $(".hide_box1").fadeOut();
                                }

                            },
                        error:
                            function(data,textStatus){


                            }
                    });

                }
                else{
                    $.ajax({
                        type: 'POST',
                        url:addressAdd_url,
                        dataType :'json',
                        data:{
                            province:province,
                            city:city,
                            district:district,
                            street:street,
                            address:detail,
                            name:pname,
                            mobile:tele,
                            isDefault:defa,
                            telephone:mobile1
                        },
                        success:
                            function(data){
                                if(data==101){
                                    error("每项必填");
                                    return false;
                                }else if(data==100){
                                    error("当前地址已存在");
                                    return false;
                                }else if(defa == 1){
                                    $(".same").removeClass("pay").addClass("def").attr("data-default","0").text("设为默认地址");
                                    add_address = "<tr id='"+ data +"'>"
                                        +         "<th class='col1'>"+pname+"</th>"
                                        +         "<th class='col2'><span class='addressDetail1'>"+province1+"</span><span class='addressDetail2'>"+city1+"</span><span class='addressDetail3'>"+district1+"</span><span class='addressDetail4'>"+street1+"</span><span class='addressDetail5'>"+detail+"</span></th>"
                                        +         "<th class='col3'>"+tele+"</th>"
                                        +         "<th class='col4'>"
                                        +         "<div class='edit'>"
                                        +         "<p class='address_change' data-uuid='"+ data +"' data-default='"+ defa +"'>编辑</p>"
                                        +         "<p class='address_delete' data-uuid='"+ data +"'>删除</p>"
                                        +         "<a class='same pay' data-uuid='"+ data +"' data-default='"+ defa +"'>默认地址</a>"
                                        +         "</div>"
                                        +         "</th>"
                                        +         "</tr>";
                                    $(".adds").prepend(add_address);
                                    $(".hide_box1").fadeOut();
                                }else if(defa ==0){
                                    add_address = "<tr id='"+ data +"'>"
                                        +         "<th class='col1'>"+pname+"</th>"
                                        +         "<th class='col2'><span class='addressDetail1'>"+province1+"</span><span class='addressDetail2'>"+city1+"</span><span class='addressDetail3'>"+district1+"</span><span class='addressDetail4'>"+street1+"</span><span class='addressDetail5'>"+detail+"</span></th>"
                                        +         "<th class='col3'>"+tele+"</th>"
                                        +         "<th class='col4'>"
                                        +         "<div class='edit'>"
                                        +         "<p class='address_change' data-uuid='"+ data +"' data-default='"+ defa +"'>编辑</p>"
                                        +         "<p class='address_delete' data-uuid='"+ data +"'>删除</p>"
                                        +         "<a class='same def' data-uuid='"+ data +"' data-default='"+ defa +"'>设为默认地址</a>"
                                        +         "</div>"
                                        +         "</th>"
                                        +         "</tr>";
                                    $(".adds").prepend(add_address);
                                    $(".hide_box1").fadeOut();

                                }
                                //编辑地址
                                $(".address_change").click(function(){

                                    $(".name").val("");
                                    $(".tele").val("");
                                    $(".mobil").val("");
                                    $(".adddetail").val("");
                                    $("#selprovince").val("");
                                    $("#selcity").val("");
                                    $("#seldistrict").val("");
                                    $("#selstreet").val("");
                                    $("input[name=checked]").attr("checked",false);

                                    var uid = $(this).attr("data-uuid");
                                    var dfa = $(this).attr("data-default");

                                    $.ajax({
                                        type: 'POST',
                                        url:search_url,
                                        dataType :'json',
                                        data:{
                                            goodsAddressUuid:uid
                                        },
                                        success:
                                            function(data){


                                                var n= data.name;
                                                var m= data.mobile;
                                                var t= data.telephone;
                                                var a= data.address;
                                                var p= data.province;
                                                var c= data.city;
                                                var d= data.district;
                                                var s= data.street;




                                                function onSelectChange(obj,toSelId){
                                                    setSelect(obj.value,toSelId);
                                                }
                                                function setSelect(fromSelVal,toSelId){
                                                    //alert(document.getElementById("province").selectedIndex);
                                                    document.getElementById(toSelId).innerHTML="";
                                                    jQuery.ajax({
                                                        url: select_url,
                                                        cache : false,
                                                        data : "parent=" + fromSelVal,
                                                        success : function(data) {
                                                            createSelectObj(data, toSelId);
                                                        }
                                                    });
                                                }
                                                function createSelectObj(data, toSelId) {
                                                    var arr = JSON.parse(data);
                                                    if (arr != null && arr.length > 0) {

                                                        if (toSelId == 'selstreet') {
                                                            $("#"+toSelId).show();
                                                        }


                                                        var obj = document.getElementById(toSelId);
                                                        obj.innerHTML = "";
                                                        var nullOp = document.createElement("option");
                                                        nullOp.setAttribute("value", "");
                                                        nullOp.appendChild(document.createTextNode("请选择"));
                                                        obj.appendChild(nullOp);
                                                        for ( var o in arr) {
                                                            var op = document.createElement("option");

                                                            op.setAttribute("value", arr[o].id);
                                                            //op.text=arr[o].name;//这一句在ie下不起作用，用下面这一句或者innerHTML
                                                            if (toSelId == 'selprovince') {
                                                                if(arr[o].id==p){
                                                                    op.setAttribute("selected", 'selected');
                                                                }
                                                                op
                                                                    .appendChild(document
                                                                        .createTextNode(arr[o].province));
                                                            } else if (toSelId == 'selcity') {
                                                                if(arr[o].id==c){
                                                                    op.setAttribute("selected", 'selected');
                                                                }
                                                                op.appendChild(document.createTextNode(arr[o].city));
                                                            } else if (toSelId == 'seldistrict') {
                                                                if(arr[o].id==d){
                                                                    op.setAttribute("selected", 'selected');
                                                                }
                                                                op
                                                                    .appendChild(document
                                                                        .createTextNode(arr[o].district));
                                                            }else if (toSelId == 'selstreet') {
                                                                if(arr[o].id==s){
                                                                    op.setAttribute("selected", 'selected');
                                                                }
                                                                op
                                                                    .appendChild(document
                                                                        .createTextNode(arr[o].street));
                                                            }
                                                            obj.appendChild(op);
                                                        }
                                                    }else{
                                                        if (toSelId == 'selstreet') {
                                                            var obj = document.getElementById(toSelId);
                                                            $("#"+toSelId).hide();
                                                        }
                                                    }
                                                }
                                                setSelect('1', 'selprovince');
                                                setSelect(p, 'selcity');
                                                setSelect(c, 'seldistrict');

                                                if(s!=null && s > 0){
                                                    setSelect(d, 'selstreet');
                                                }else if(s==""){
                                                    $("#selstreet").hide();
                                                }
                                                $(".name").val(n);
                                                $(".tele").val(m);
                                                $(".mobil").val(t);
                                                $(".adddetail").val(a);
                                                $("#selprovince").val(p);
                                                $("#selcity").val(c);
                                                $("#seldistrict").val(d);
                                                $("#selstreet").val(s);
                                                $("#ok").attr("data-uuid",uid);
                                                if(dfa == 1){
                                                    $("input[name=checked]").attr("checked",true);
                                                }else{
                                                    $("input[name=checked]").attr("checked",false);
                                                }

                                                $(".hide_box1").fadeIn();
                                            },
                                        error:
                                            function(data,textStatus){

                                            }
                                    });

                                });

                                //删除地址
                                $(".address_delete").click(function(){
                                    var uuid = $(this).attr("data-uuid");
                                    $(".black_box").fadeIn(500);
                                    $("#delbtn").attr("data-uuid",uuid);
                                });
                                //取消删除
                                $("#cancle").click(function(){
                                    $(".black_box").fadeOut(500);
                                });
                                //确认删除
                                $("#delbtn").click(function(){
                                    var id = $(this).attr("data-uuid");
                                    var obj = $(this);

                                    $.ajax({
                                        type: 'POST',
                                        url:addressDelete_url,
                                        dataType : "json" ,
                                        data:{
                                            goodsAddressUuid:id
                                        },
                                        success:
                                            function(data){

                                                window.location.reload();

                                            },
                                        error:
                                            function(data,textStatus){

                                            }
                                    });
                                });

                                //设为默认地址
                                $(".same").click(function(){

                                    var id = $(this).attr("data-uuid");
                                    var o = $(this);


                                    $.ajax({
                                        type: 'POST',
                                        url:addressDefault_url,
                                        dataType : "json" ,
                                        data:{
                                            goodsAddressUuid:id
                                        },
                                        success:
                                            function(data){

                                                $(".same").removeClass("pay").addClass("def").attr("data-default","0").text("设为默认地址");
                                                $(o).removeClass("def").addClass("pay").attr("data-default","1").text("默认地址");
                                                $(o).prev().prev().attr("data-default","1");

                                            },
                                        error:
                                            function(data,textStatus){

                                            }
                                    });
                                });






                            },
                        error:
                            function(data,textStatus){

                            }
                    });
                }




            }



        });


        //删除地址
        $(".address_delete").click(function(){
            var uuid = $(this).attr("data-uuid");
            $(".black_box").fadeIn(500);
            $("#delbtn").attr("data-uuid",uuid);
        });
        //取消删除
        $("#cancle").click(function(){
            $(".black_box").fadeOut(500);
        });
        //确认删除
        $("#delbtn").click(function(){
            var id = $(this).attr("data-uuid");
            var obj = $(this);

            $.ajax({
                type: 'POST',
                url:addressDelete_url,
                dataType : "json" ,
                data:{
                    goodsAddressUuid:id
                },
                success:
                    function(data){

                        window.location.reload();

                    },
                error:
                    function(data,textStatus){

                    }
            });
        });

        //设为默认地址
        $(".same").click(function(){

            var id = $(this).attr("data-uuid");
            var o = $(this);


            $.ajax({
                type: 'POST',
                url:addressDefault_url,
                dataType : "json" ,
                data:{
                    goodsAddressUuid:id
                },
                success:
                    function(data){

                        $(".same").removeClass("pay").addClass("def").attr("data-default","0").text("设为默认地址");
                        $(o).removeClass("def").addClass("pay").attr("data-default","1").text("默认地址");
                        $(o).prev().prev().attr("data-default","1");

                    },
                error:
                    function(data,textStatus){

                    }
            });
        });

    }


});