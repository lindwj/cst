

function onSelectChange(obj,toSelId){
    setSelect(obj.value,toSelId);
}
function setSelect(fromSelVal,toSelId){
    document.getElementById(toSelId).innerHTML="";
    jQuery.ajax({
        url: select_url,
        cache : false,
        data : "parent=" + fromSelVal,
        success : function(data) {
            createSelectObj(data, toSelId);
        }
    });
}
function createSelectObj(data, toSelId) {
    var arr = JSON.parse(data);
    if (arr != null && arr.length > 0) {

        if (toSelId == 'selstreet') {
            $("#"+toSelId).show();
        }


        var obj = document.getElementById(toSelId);
        obj.innerHTML = "";
        var nullOp = document.createElement("option");
        nullOp.setAttribute("value", "");
        nullOp.appendChild(document.createTextNode("请选择"));
        obj.appendChild(nullOp);
        for ( var o in arr) {
            var op = document.createElement("option");
            op.setAttribute("value", arr[o].id);
            //op.text=arr[o].name;//这一句在ie下不起作用，用下面这一句或者innerHTML
            if (toSelId == 'selprovince') {
                op
                    .appendChild(document
                        .createTextNode(arr[o].province));
            } else if (toSelId == 'selcity') {
                op.appendChild(document.createTextNode(arr[o].city));
            } else if (toSelId == 'seldistrict') {
                op
                    .appendChild(document
                        .createTextNode(arr[o].district));
            } else if (toSelId == 'selstreet') {
                op.appendChild(document.createTextNode(arr[o].street));
            }
            obj.appendChild(op);
        }
    }else{
        if (toSelId == 'selstreet') {
            var obj = document.getElementById(toSelId);
            $("#"+toSelId).hide();
        }
    }
}
setSelect('1', 'selprovince');
$(function(){



    var o=window.location.href.split("?")[1];

    $.ajax({
        type:'post',
        url:nowpay_url,
        dataType:'json',
        data:o,
        success:
            function(data){
                if(data.state==001){
                    window.location.href= login_url;
                }else{
                    getorder(data);
                }
            },
        error:
            function(data){
                //error("请先登录后再访问！");
                //window.location.href= login_url;
            }

    });





    var footer = "";
    var str = "";
    var shop_name = "";
    var productxjy= "";
    function getorder(info){
        var faddress = "";
        var address = "";
        var address1 = "";
        var pro = "";
        var jsdz = "";

        footer = "<div class='leave_message'>"
            +    "<p class='p1'>配送商家</p>"
            +    "<p class='p2' id='sname'>"+ shop_name +"</p>"
            +    "</div>"
            +    "<div class='leave_message'>"
            +    "<p class='p1'>给卖家留言</p>"
            +    "<input id='beizhu' type='text' maxlength='50' placeholder='选填:对本次交易的说明,最多50个字'>"
            +    "</div>"
            +    "<div class='buy_price'>"
            +    "<div class='price1'>"
            +    "<p>￥<span>"+ info.totalFromBdh.toFixed(2) +"</span></p>"
            +    "<p>￥<span>0.00</span></p>"
            +    "</div>"
            +    "<div class='price2'>"
            +    "<p>商品合计 :</p>"
            +    "<p>运费 :</p>"
            +    "</div>"
            +    "<div class='clear'></div>"
            +    "</div>"
            +    "<div class='buy_pay'>"
            +    "<p class='p4'>￥<span id='totalp' data-allp='"+ info.totalFromBdh +"'>"+ info.totalFromBdh.toFixed(2) +"</span></p>"
            +    "<p class='p3'>应付金额 :</p>"
            +    "<div class='clear'></div>"
            +    "<button class='buy' id='pay' data-id='"+ info.shopId +"'>去付款</button>"
            +    "<div class='clear'></div>"
            +    "<p class='adres2'></p>"
            +    "<div class='clear'></div>"
            +    "</div>";
        $(".buy_detail").append(footer);

        if( info.goodsAddress == null && info.goodsAddressListadd =="" && info.goodsAddressList ==""){

            $(".adds").append("<p class='nullw'>当前地址为空，请先添加地址</p>");

        }else{

            if(info.goodsAddress == null){
                faddress = "";
            }else{
                if(info.shopName == null){
                    shop_name = "";
                }else{
                    shop_name = info.shopName;
                }



                if(info.goodsAddress.streetstr == null){
                    str = "";
                }else{
                    str = info.goodsAddress.streetstr;
                }

                //第一条默认地址
                faddress = "<div class='address_detail'>"
                    +          "<p class='address_default2 address_default'>寄送地址<i class='iconfont defaulticon'>&#xe6e8;</i></p>"
                    +          "<span class='edit_box'>"
                    +          "<p class='adres' id='"+ info.goodsAddress.goodsAddressUuid +"'><span class='addressDetail1'>"+ info.goodsAddress.name +"</span>&nbsp;&nbsp;&nbsp;<span class='addressDetail2'>"+ info.goodsAddress.provincestr +"</span>&nbsp;<span class='addressDetail3'>"+ info.goodsAddress.citystr +"</span>&nbsp;<span class='addressDetail4'>"+ info.goodsAddress.districtstr +"</span>&nbsp;<span class='addressDetail5'>"+ str +"</span>&nbsp;<span class='addressDetail6'>"+ info.goodsAddress.address +"</span>&nbsp;&nbsp;&nbsp;<span class='addressDetail7'>"+ info.goodsAddress.mobile +"</span></p>"
                    +          "<p class='address_edit address_delete' data-uuid='"+ info.goodsAddress.goodsAddressUuid +"'>删除</p>"
                    +          "<p class='address_edit address_change' data-uuid='"+ info.goodsAddress.goodsAddressUuid +"' data-default='"+ info.goodsAddress.isDefault +"'>编辑</p>"
                    +          "<p class='def addDefault' data-default='"+ info.goodsAddress.isDefault +"' data-uuid='"+ info.goodsAddress.goodsAddressUuid +"'>默认地址</p>"
                    +          "</span>"
                    +          "<div class='clear'></div>"
                    +          "</div>";
                $(".adds").append(faddress);
                jsdz = "<span class='c1'>"+info.goodsAddress.name+"</span>"+"&nbsp;&nbsp;"+"<span class='c2'>"+info.goodsAddress.mobile+"</span>"+"<br>"+"<span class='c3'>"+info.goodsAddress.provincestr+"</span>"+"<span class='c4'>"+info.goodsAddress.citystr+"</span>"+"<span class='c5'>"+info.goodsAddress.districtstr+"</span>"+"<span class='c6'>"+str+"</span>"+"<span class='c7'>"+info.goodsAddress.address+"</span>";
                $(".adres2").append(jsdz);
                $(".adres2").attr("data-uid",info.goodsAddress.goodsAddressUuid);
            }


            var street = "";
            //地址列表
            $.each(info.goodsAddressListadd,function(j,jtem){
                if(jtem.streetstr==null){
                    street = "";
                }else{
                    street = jtem.streetstr;
                }

                address += "<div class='address_detail'>"
                    +         "<p class='address_default2'>设为寄送地址</p>"
                    +         "<span class='edit_box'>"
                    +         "<p class='adres' id='"+ jtem.goodsAddressUuid +"'><span class='addressDetail1'>"+ jtem.name +"</span>&nbsp;&nbsp;&nbsp;<span class='addressDetail2'>"+ jtem.provincestr +"</span>&nbsp;<span class='addressDetail3'>"+ jtem.citystr +"</span>&nbsp;<span class='addressDetail4'>"+ jtem.districtstr +"</span>&nbsp;<span class='addressDetail5'>"+ street +"</span>&nbsp;<span class='addressDetail6'>"+ jtem.address +"</span>&nbsp;&nbsp;&nbsp;<span class='addressDetail7'>"+ jtem.mobile +"</span></p>"
                    +         "<p class='address_edit address_delete' data-uuid='"+ jtem.goodsAddressUuid +"'>删除</p>"
                    +         "<p class='address_edit address_change' data-uuid='"+ jtem.goodsAddressUuid +"' data-default='"+ jtem.isDefault +"'>编辑</p>"
                    +         "<p class='def setdefault' data-default='"+ jtem.isDefault +"' data-uuid='"+ jtem.goodsAddressUuid +"'>设为默认地址</p>"
                    +         "</span>"
                    +         "<div class='clear'></div>"
                    +         "</div>";

            });

            $(".adds").append(address);
            $(".adds").append("<div class='amore'></div>");

            var street1 = "";
            if(info.goodsAddressList !=null){

                $(".adds").append("<p class='moreadd'>更多地址<i class='iconfont moreicon'>&#xe640;</i></p>");
                $(".adds").append("<p class='moreadd1'>收起地址<i class='iconfont moreicon'>&#xe641;</i></p>");
                $(".moreadd1").hide();
                //更多地址列表
                $.each(info.goodsAddressList,function(x,xtem){
                    if(xtem.streetstr==null){
                        street1 = "";
                    }else{
                        street1 = xtem.streetstr;
                    }
                    address1 += "<div class='address_detail'>"
                        +         "<p class='address_default2'>设为寄送地址</p>"
                        +         "<span class='edit_box'>"
                        +         "<p class='adres' id='"+ xtem.goodsAddressUuid +"'><span class='addressDetail1'>"+ xtem.name +"</span>&nbsp;&nbsp;&nbsp;<span class='addressDetail2'>"+ xtem.provincestr +"</span>&nbsp;<span class='addressDetail3'>"+ xtem.citystr +"</span>&nbsp;<span class='addressDetail4'>"+ xtem.districtstr +"</span>&nbsp;<span class='addressDetail5'>"+ street1 +"</span>&nbsp;<span class='addressDetail6'>"+ xtem.address +"</span>&nbsp;&nbsp;&nbsp;<span class='addressDetail7'>"+ xtem.mobile +"</span></p>"
                        +         "<p class='address_edit address_delete' data-uuid='"+ xtem.goodsAddressUuid +"'>删除</p>"
                        +         "<p class='address_edit address_change' data-uuid='"+ xtem.goodsAddressUuid +"' data-default='"+ xtem.isDefault +"'>编辑</p>"
                        +         "<p class='def setdefault' data-default='"+ xtem.isDefault +"' data-uuid='"+ xtem.goodsAddressUuid +"'>设为默认地址</p>"
                        +         "</span>"
                        +         "<div class='clear'></div>"
                        +         "</div>";

                });
                $(".amore").append(address1).hide();


            }else{

            }

        }


        //显示更多地址
        $(".moreadd").click(function(){
            $(this).hide();
            $(".amore").show();
            $(".moreadd1").show();

        });
        //收起地址
        $(".moreadd1").click(function(){
            $(this).hide();
            $(".amore").hide();
            $(".moreadd").show();
        });



        pro += "<div class='pro_message' data-ca='"+ info.showCapacity +"' data-id='"+info.product.productUuid+"'>"
            +  "<span class='col1'>"
            +  "<img src='"+info.product.pic+"'>"
            +  "</span>"
            +  "<p class='col2'>"+info.product.name+"</p>"
            //+  "<p class='col3'>规格</p>"
            +  "<p class='col4'>¥<span>"+info.product.price.toFixed(2)+"</span></p>"
            +  "<p class='col5'>"+info.capacity+"</p>"
            +  "<p class='col6'>¥<span class='plusmoney'>"+ (info.product.price*info.capacity).toFixed(2) +"</span></p>"
            +  "<div class='clear'></div>"
            +  "</div>";
        $(".pros").append(pro);
        $("#form").append("<input type='hidden' name='productUuid' value='"+info.product.productUuid+"'>");
        $("#form").append("<input type='hidden' name='pic' value='"+info.product.pic+"'>");
        $("#form").append("<input type='hidden' name='subject' value='"+info.product.name+"'>");
        $("#form").append("<input type='hidden' name='price' value='"+info.product.price+"'>");
        $("#form").append("<input type='hidden' name='capacity' value='"+info.capacity+"'>");







        //设为默认地址
        $(".def").click(function(){

            var id = $(this).attr("data-uuid");
            var o = $(this);


            $.ajax({
                type: 'POST',
                url:addressDefault_url,
                dataType : "json" ,
                data:{
                    goodsAddressUuid:id
                },
                success:
                    function(data){

                        $(".addDefault").removeClass("addDefault").addClass("setdefault").attr("data-default","0").text("设为默认地址");
                        $(".address_change").attr("data-default","0");
                        $(o).removeClass("setdefault").addClass("addDefault").attr("data-default","1").text("默认地址");
                        $(o).prev().attr("data-default","1");

                    },
                error:
                    function(data,textStatus){

                    }
            });
        });

        //新增地址
        $("#add_new").click(function(){
            $(".name").val("");
            $(".tele").val("");
            $(".mobil").val("");
            $(".adddetail").val("");
            $("#selprovince").val("");
            $("#selcity").val("");
            $("#seldistrict").val("");
            $("#selstreet").val("");
            $("input[name=checked]").attr("checked",false);
            $(".hide_box1").fadeIn();
        });
        $("#back").click(function(){
            $(".hide_box1").fadeOut();
            $("#ok").attr("data-uuid","");
        });
         //编辑地址
        $(".address_change").click(function(){

            $(".name").val("");
            $(".tele").val("");
            $(".mobil").val("");
            $(".adddetail").val("");
            $("#selprovince").val("");
            $("#selcity").val("");
            $("#seldistrict").val("");
            $("#selstreet").val("");
            $("input[name=checked]").attr("checked",false);

            var uid = $(this).attr("data-uuid");
            var dfa = $(this).attr("data-default");

            $.ajax({
                type: 'POST',
                url:search_url,
                dataType :'json',
                data:{
                    goodsAddressUuid:uid
                },
                success:
                    function(data){


                        var n= data.name;
                        var m= data.mobile;
                        var t= data.telephone;
                        var a= data.address;
                        var p= data.province;
                        var c= data.city;
                        var d= data.district;
                        var s= data.street;


                        function onSelectChange(obj,toSelId){
                            setSelect(obj.value,toSelId);
                        }
                        function setSelect(fromSelVal,toSelId){
                            //alert(document.getElementById("province").selectedIndex);
                            document.getElementById(toSelId).innerHTML="";
                            jQuery.ajax({
                                url: select_url,
                                cache : false,
                                data : "parent=" + fromSelVal,
                                success : function(data) {
                                    createSelectObj(data, toSelId);
                                }
                            });
                        }
                        function createSelectObj(data, toSelId) {
                            var arr = JSON.parse(data);
                            if (arr != null && arr.length > 0) {

                                if (toSelId == 'selstreet') {
                                    $("#"+toSelId).show();
                                }


                                var obj = document.getElementById(toSelId);
                                obj.innerHTML = "";
                                var nullOp = document.createElement("option");
                                nullOp.setAttribute("value", "");
                                nullOp.appendChild(document.createTextNode("请选择"));
                                obj.appendChild(nullOp);
                                for ( var o in arr) {
                                    var op = document.createElement("option");

                                    op.setAttribute("value", arr[o].id);
                                    //op.text=arr[o].name;//这一句在ie下不起作用，用下面这一句或者innerHTML
                                    if (toSelId == 'selprovince') {
                                        if(arr[o].id==p){
                                            op.setAttribute("selected", 'selected');
                                        }
                                        op
                                            .appendChild(document
                                                .createTextNode(arr[o].province));
                                    } else if (toSelId == 'selcity') {
                                        if(arr[o].id==c){
                                            op.setAttribute("selected", 'selected');
                                        }
                                        op.appendChild(document.createTextNode(arr[o].city));
                                    } else if (toSelId == 'seldistrict') {
                                        if(arr[o].id==d){
                                            op.setAttribute("selected", 'selected');
                                        }
                                        op
                                            .appendChild(document
                                                .createTextNode(arr[o].district));
                                    }else if (toSelId == 'selstreet') {
                                        if(arr[o].id==s){
                                            op.setAttribute("selected", 'selected');
                                        }
                                        op
                                            .appendChild(document
                                                .createTextNode(arr[o].street));
                                    }
                                    obj.appendChild(op);
                                }
                            }else{
                                if (toSelId == 'selstreet') {
                                    var obj = document.getElementById(toSelId);
                                    $("#"+toSelId).hide();
                                }
                            }
                        }
                        setSelect('1', 'selprovince');
                        setSelect(p, 'selcity');
                        setSelect(c, 'seldistrict');

                        if(s!=null && s > 0){
                            setSelect(d, 'selstreet');
                        }
                        $(".name").val(n);
                        $(".tele").val(m);
                        $(".mobil").val(t);
                        $(".adddetail").val(a);
                        $("#selprovince").val(p);
                        $("#selcity").val(c);
                        $("#seldistrict").val(d);
                        $("#selstreet").val(s);
                        $("#ok").attr("data-uuid",uid);
                        if(dfa == 1){
                            $("input[name=checked]").attr("checked",true);
                        }else{
                            $("input[name=checked]").attr("checked",false);
                        }

                        $(".hide_box1").fadeIn();
                    },
                error:
                    function(data,textStatus){

                    }
            });

        });

        //确认添加
        $("#ok").click(function(){

            $(".nullw").remove();
            var add_address = "";
            var pname = $(".name").val();
            var tele = $(".tele").val();
            //var mobile1 = $(".mobil").val();
            var detail = $(".adddetail").val();
            var province = $("#selprovince").val();
            var city = $("#selcity").val();
            var district = $("#seldistrict").val();
            var street = $("#selstreet").val();


            var uid = $(this).attr("data-uuid");

            if(street == null){
                street = "";
            }

            var province1 = $("#selprovince").find("option:selected").text();
            var city1 = $("#selcity").find("option:selected").text();
            var district1 = $("#seldistrict").find("option:selected").text();
            var street1 = $("#selstreet").find("option:selected").text();
            if(street1 == null){
                street1 = "";
            }
            if($("input[name=checked]").is(':checked')){
                $(this).attr("data-default","1");
            }else{
                $(this).attr("data-default","0");
            }

            var defa = $(this).attr("data-default");


            var reg = /(1[3-9]\d{9}$)/;


            if(pname == ""){
                error("请添加收货人姓名");
                return false;
            }else if(tele == ""){
                error("请添加收货人手机号");
                return false;
            }else if(!reg.test(tele)){
                error("请输入有效的11位手机号");
                return false;
            }else if(detail == ""){
                error("请添加收货人地址");
                return false;
            }
            else{

                if(uid != ""&& uid!=null && uid!=undefined){

                    $.ajax({
                        type: 'POST',
                        url:addressEdit_url,
                        dataType : "json" ,
                        data:{
                            goodsAddressUuid:uid,
                            province:province,
                            city:city,
                            district:district,
                            street:street,
                            address:detail,
                            name:pname,
                            mobile:tele,
                            isDefault:defa
                        },
                        success:
                            function(data){
                                var id = "#"+uid;
                                if(data==101){
                                    error("每项必填");
                                    return false;
                                }else if(data==100){
                                    error("当前地址已存在");
                                    return false;
                                }else if(defa == 1){
                                    $(".address_default2").removeClass("address_default");
                                    $(".address_default2").text("设为寄送地址");

                                    $(id).children().eq(0).text(pname);
                                    $(id).children().eq(1).text(province1);
                                    $(id).children().eq(2).text(city1);
                                    $(id).children().eq(3).text(district1);
                                    $(id).children().eq(4).text(street1);
                                    $(id).children().eq(5).text(detail);
                                    $(id).children().eq(6).text(tele);
                                    $(".def").removeClass("addDefault").addClass("setdefault").attr("data-default","0").text("设为默认地址");
                                    $(id).nextAll().eq(1).attr("data-default","1");
                                    $(id).nextAll().eq(2).removeClass("setdefault").addClass("addDefault").attr("data-default","1").text("默认地址");
                                    $(id).parent().prev().addClass("address_default").attr("data-send","1").text("寄送地址").append("<i class='iconfont defaulticon'>&#xe6e8;</i>");

                                    $(".hide_box1").fadeOut();
                                    $(".adres2").empty();
                                    $(".adres2").append("<span class='c1'>"+pname+"</span>"+"&nbsp;&nbsp;"+"<span class='c2'>"+tele+"</span>"+"<br>"+"<span class='c3'>"+province1+"</span>"+"<span class='c4'>"+city1+"</span>"+"<span class='c5'>"+district1+"</span>"+"<span class='c6'>"+street1+"</span>"+"<span class='c7'>"+detail+"</span>");
                                    $(".adres2").attr("data-uid",uid);
                                }else if(defa ==0){
                                    $(".address_default2").removeClass("address_default");
                                    $(".address_default2").text("设为寄送地址");

                                    $(id).children().eq(0).text(pname);
                                    $(id).children().eq(1).text(province1);
                                    $(id).children().eq(2).text(city1);
                                    $(id).children().eq(3).text(district1);
                                    $(id).children().eq(4).text(street1);
                                    $(id).children().eq(5).text(detail);
                                    $(id).children().eq(6).text(tele);
                                    $(id).nextAll().eq(1).attr("data-default","0");
                                    $(id).nextAll().eq(2).removeClass("addDefault").addClass("setdefault").attr("data-default","0").text("设为默认地址");
                                    $(id).parent().prev().addClass("address_default").attr("data-send","1").text("寄送地址").append("<i class='iconfont defaulticon'>&#xe6e8;</i>");
                                    $(".hide_box1").fadeOut();
                                    $(".adres2").empty();
                                    $(".adres2").append("<span class='c1'>"+pname+"</span>"+"&nbsp;&nbsp;"+"<span class='c2'>"+tele+"</span>"+"<br>"+"<span class='c3'>"+province1+"</span>"+"<span class='c4'>"+city1+"</span>"+"<span class='c5'>"+district1+"</span>"+"<span class='c6'>"+street1+"</span>"+"<span class='c7'>"+detail+"</span>");
                                    $(".adres2").attr("data-uid",uid);
                                }

                            },
                        error:
                            function(data,textStatus){


                            }
                    });

                }else{
                    $.ajax({
                        type: 'POST',
                        url:addressAdd_url,
                        dataType :'json',
                        data:{
                            province:province,
                            city:city,
                            district:district,
                            street:street,
                            address:detail,
                            name:pname,
                            mobile:tele,
                            isDefault:defa
                        },
                        success:
                            function(data){
                                if(data==101){
                                    error("每项必填");
                                    return false;
                                }else if(data==100){
                                    error("当前地址已存在");
                                    return false;
                                }else if(defa == 1){
                                    $(".address_default2").removeClass("address_default");
                                    $(".address_default2").text("设为寄送地址");
                                    $(".def").removeClass("addDefault").addClass("setdefault").attr("data-default","0").text("设为默认地址");
                                    add_address = "<div class='address_detail'>"
                                        +          "<p class='address_default2 address_default'>寄送地址<i class='iconfont defaulticon'>&#xe6e8;</i></p>"
                                        +          "<span class='edit_box'>"
                                        +          "<p class='adres' id='"+ data +"'><span class='addressDetail1'>"+ pname +"</span>&nbsp;&nbsp;&nbsp;<span class='addressDetail2'>"+ province1 +"</span>&nbsp;<span class='addressDetail3'>"+ city1 +"</span>&nbsp;<span class='addressDetail4'>"+ district1 +"</span>&nbsp;<span class='addressDetail5'>"+ street1 +"</span>&nbsp;<span class='addressDetail6'>"+ detail +"</span>&nbsp;&nbsp;&nbsp;<span class='addressDetail7'>"+ tele +"</span></p>"
                                        +          "<p class='address_edit address_delete' data-uuid='"+ data +"'>删除</p>"
                                        +          "<p class='address_edit address_change' data-uuid='"+ data +"' data-default='"+ defa +"'>编辑</p>"
                                        +          "<p class='def addDefault' data-default='"+ defa +"' data-uuid='"+ data +"'>默认地址</p>"
                                        +          "</span>"
                                        +          "<div class='clear'></div>"
                                        +          "</div>";
                                    $(".adds").prepend(add_address);
                                    $(".hide_box1").fadeOut();
                                    $(".adres2").empty();
                                    $(".adres2").append("<span class='c1'>"+pname+"</span>"+"&nbsp;&nbsp;"+"<span class='c2'>"+tele+"</span>"+"<br>"+"<span class='c3'>"+province+"</span>"+"<span class='c4'>"+city+"</span>"+"<span class='c5'>"+district+"</span>"+"<span class='c6'>"+street+"</span>"+"<span class='c7'>"+detail+"</span>");
                                    $(".adres2").attr("data-uid",data);
                                }else if(defa ==0){
                                    $(".address_default2").removeClass("address_default");
                                    $(".address_default2").text("设为寄送地址");
                                    add_address = "<div class='address_detail'>"
                                        +          "<p class='address_default2 address_default'>寄送地址<i class='iconfont defaulticon'>&#xe6e8;</i></p>"
                                        +          "<span class='edit_box'>"
                                        +          "<p class='adres' id='"+ data +"'><span class='addressDetail1'>"+ pname +"</span>&nbsp;&nbsp;&nbsp;<span class='addressDetail2'>"+ province1 +"</span>&nbsp;<span class='addressDetail3'>"+ city1 +"</span>&nbsp;<span class='addressDetail4'>"+ district1 +"</span>&nbsp;<span class='addressDetail5'>"+ street1 +"</span>&nbsp;<span class='addressDetail6'>"+ detail +"</span>&nbsp;&nbsp;&nbsp;<span class='addressDetail7'>"+ tele +"</span></p>"
                                        +          "<p class='address_edit address_delete' data-uuid='"+ data +"'>删除</p>"
                                        +          "<p class='address_edit address_change' data-uuid='"+ data +"' data-default='"+ defa +"'>编辑</p>"
                                        +         "<p class='def setdefault' data-default='"+ defa +"' data-uuid='"+ data +"'>设为默认地址</p>"
                                        +          "</span>"
                                        +          "<div class='clear'></div>"
                                        +          "</div>";
                                    $(".adds").prepend(add_address);
                                    $(".hide_box1").fadeOut();
                                    $(".adres2").empty();
                                    $(".adres2").append("<span class='c1'>"+pname+"</span>"+"&nbsp;&nbsp;"+"<span class='c2'>"+tele+"</span>"+"<br>"+"<span class='c3'>"+province+"</span>"+"<span class='c4'>"+city+"</span>"+"<span class='c5'>"+district+"</span>"+"<span class='c6'>"+street+"</span>"+"<span class='c7'>"+detail+"</span>");
                                    $(".adres2").attr("data-uid",data);

                                }
                                //鼠标移入显示
                                $(".address_detail").mouseenter(function(){
                                    $(this).children("span").css("background-color","#fef9ef");
                                    $(this).children("span").children().eq(1).show();
                                    $(this).children("span").children().eq(2).show();
                                    $(this).children("span").children().eq(3).show();
                                });
                                //鼠标移出隐藏
                                $(".address_detail").mouseleave(function(){

                                    var defa = $(this).children("span").children().eq(3).attr("data-default");
                                    $(this).children("span").css("background-color","#ffffff");
                                    $(this).children("span").children().eq(1).hide();
                                    $(this).children("span").children().eq(2).hide();
                                    if(defa ==0){
                                        $(this).children("span").children().eq(3).hide();
                                    }


                                });

                                //编辑地址
                                $(".address_change").click(function(){

                                    $(".name").val("");
                                    $(".tele").val("");
                                    $(".mobil").val("");
                                    $(".adddetail").val("");
                                    $("#selprovince").val("");
                                    $("#selcity").val("");
                                    $("#seldistrict").val("");
                                    $("#selstreet").val("");
                                    $("input[name=checked]").attr("checked",false);

                                    var uid = $(this).attr("data-uuid");
                                    var dfa = $(this).attr("data-default");

                                    $.ajax({
                                        type: 'POST',
                                        url:search_url,
                                        dataType :'json',
                                        data:{
                                            goodsAddressUuid:uid
                                        },
                                        success:
                                            function(data){


                                                var n= data.name;
                                                var m= data.mobile;
                                                var t= data.telephone;
                                                var a= data.address;
                                                var p= data.province;
                                                var c= data.city;
                                                var d= data.district;
                                                var s= data.street;


                                                function onSelectChange(obj,toSelId){
                                                    setSelect(obj.value,toSelId);
                                                }
                                                function setSelect(fromSelVal,toSelId){
                                                    //alert(document.getElementById("province").selectedIndex);
                                                    document.getElementById(toSelId).innerHTML="";
                                                    jQuery.ajax({
                                                        url: select_url,
                                                        cache : false,
                                                        data : "parent=" + fromSelVal,
                                                        success : function(data) {
                                                            createSelectObj(data, toSelId);
                                                        }
                                                    });
                                                }
                                                function createSelectObj(data, toSelId) {
                                                    var arr = JSON.parse(data);
                                                    if (arr != null && arr.length > 0) {

                                                        if (toSelId == 'selstreet') {
                                                            $("#"+toSelId).show();
                                                        }


                                                        var obj = document.getElementById(toSelId);
                                                        obj.innerHTML = "";
                                                        var nullOp = document.createElement("option");
                                                        nullOp.setAttribute("value", "");
                                                        nullOp.appendChild(document.createTextNode("请选择"));
                                                        obj.appendChild(nullOp);
                                                        for ( var o in arr) {
                                                            var op = document.createElement("option");

                                                            op.setAttribute("value", arr[o].id);
                                                            //op.text=arr[o].name;//这一句在ie下不起作用，用下面这一句或者innerHTML
                                                            if (toSelId == 'selprovince') {
                                                                if(arr[o].id==p){
                                                                    op.setAttribute("selected", 'selected');
                                                                }
                                                                op
                                                                    .appendChild(document
                                                                        .createTextNode(arr[o].province));
                                                            } else if (toSelId == 'selcity') {
                                                                if(arr[o].id==c){
                                                                    op.setAttribute("selected", 'selected');
                                                                }
                                                                op.appendChild(document.createTextNode(arr[o].city));
                                                            } else if (toSelId == 'seldistrict') {
                                                                if(arr[o].id==d){
                                                                    op.setAttribute("selected", 'selected');
                                                                }
                                                                op
                                                                    .appendChild(document
                                                                        .createTextNode(arr[o].district));
                                                            }else if (toSelId == 'selstreet') {
                                                                if(arr[o].id==s){
                                                                    op.setAttribute("selected", 'selected');
                                                                }
                                                                op
                                                                    .appendChild(document
                                                                        .createTextNode(arr[o].street));
                                                            }
                                                            obj.appendChild(op);
                                                        }
                                                    }else{
                                                        if (toSelId == 'selstreet') {
                                                            var obj = document.getElementById(toSelId);
                                                            $("#"+toSelId).hide();
                                                        }
                                                    }
                                                }
                                                setSelect('1', 'selprovince');
                                                setSelect(p, 'selcity');
                                                setSelect(c, 'seldistrict');

                                                if(s!=null && s > 0){
                                                    setSelect(d, 'selstreet');
                                                }
                                                $(".name").val(n);
                                                $(".tele").val(m);
                                                $(".mobil").val(t);
                                                $(".adddetail").val(a);
                                                $("#selprovince").val(p);
                                                $("#selcity").val(c);
                                                $("#seldistrict").val(d);
                                                $("#selstreet").val(s);
                                                $("#ok").attr("data-uuid",uid);
                                                if(dfa == 1){
                                                    $("input[name=checked]").attr("checked",true);
                                                }else{
                                                    $("input[name=checked]").attr("checked",false);
                                                }

                                                $(".hide_box1").fadeIn();
                                            },
                                        error:
                                            function(data,textStatus){

                                            }
                                    });

                                });

                                //删除地址
                                $(".address_delete").click(function(){
                                    var uuid = $(this).attr("data-uuid");
                                    $(".black_box").fadeIn(500);
                                    $("#delbtn").attr("data-uuid",uuid);
                                });
                                //取消删除
                                $("#cancle").click(function(){
                                    $(".black_box").fadeOut(500);
                                });
                                //确认删除
                                $("#delbtn").click(function(){
                                    var id = $(this).attr("data-uuid");
                                    var obj = $(this);

                                    $.ajax({
                                        type: 'POST',
                                        url:addressDelete_url,
                                        dataType : "json" ,
                                        data:{
                                            goodsAddressUuid:id
                                        },
                                        success:
                                            function(data){

                                                window.location.reload();

                                            },
                                        error:
                                            function(data,textStatus){

                                            }
                                    });
                                });

                                //设为寄送地址
                                $(".address_default2").click(function(){
                                    $(".adres2").empty();

                                    $(".address_default2").removeClass("address_default");
                                    $(".address_default2").text("设为寄送地址");
                                    $(this).addClass("address_default");
                                    $(this).text("寄送地址");
                                    $(this).append("<i class='iconfont defaulticon'>&#xe6e8;</i>");

                                    var n = $(this).next().children().eq(0).children().eq(0).text();
                                    var uui = $(this).next().children().eq(0).attr("id");
                                    var s1 = $(this).next().children().eq(0).children().eq(1).text();
                                    var s2 = $(this).next().children().eq(0).children().eq(2).text();
                                    var q = $(this).next().children().eq(0).children().eq(3).text();
                                    var x = $(this).next().children().eq(0).children().eq(4).text();
                                    var a = $(this).next().children().eq(0).children().eq(5).text();
                                    var t = $(this).next().children().eq(0).children().eq(6).text();
                                    $(".adres2").append("<span class='c1'>"+n+"</span>"+"&nbsp;&nbsp;"+"<span class='c2'>"+t+"</span>"+"<br>"+"<span class='c3'>"+s1+"</span>"+"<span class='c4'>"+s2+"</span>"+"<span class='c5'>"+q+"</span>"+"<span class='c6'>"+x+"</span>"+"<span class='c7'>"+a+"</span>");
                                    $(".adres2").attr("data-uid",uui);



                                    var productuuid = $(".pro_message").attr("data-id");
                                    $.ajax({
                                        type: 'POST',
                                        url:shopid_url,
                                        dataType : "json" ,
                                        data: "goodsAddressUuid=" + uui +"&productUuid=" + productuuid,
                                        success:
                                            function(data){
                                                $(".p2").text(data.shopName);
                                                $("#pay").attr("data-id",data.shopId);
                                                $(".pro_message").attr("data-ca",data.capacity);
                                            },
                                        error:
                                            function(data,textStatus){

                                            }
                                    });


                                });

                                //设为默认地址
                                $(".def").click(function(){

                                    var id = $(this).attr("data-uuid");
                                    var o = $(this);


                                    $.ajax({
                                        type: 'POST',
                                        url:addressDefault_url,
                                        dataType : "json" ,
                                        data:{
                                            goodsAddressUuid:id
                                        },
                                        success:
                                            function(data){

                                                $(".def").removeClass("addDefault").addClass("setdefault").attr("data-default","0").text("设为默认地址").css("display","none");
                                                $(".address_change").attr("data-default","0");
                                                $(o).removeClass("setdefault").addClass("addDefault").attr("data-default","1").text("默认地址");
                                                $(o).prev().attr("data-default","1");

                                            },
                                        error:
                                            function(data,textStatus){

                                            }
                                    });
                                });






                            },
                        error:
                            function(data,textStatus){

                            }
                    });
                }




            }



        });


        //删除地址
        $(".address_delete").click(function(){
            var uuid = $(this).attr("data-uuid");
            $(".black_box").fadeIn(500);
            $("#delbtn").attr("data-uuid",uuid);
        });
        //取消删除
        $("#cancle").click(function(){
            $(".black_box").fadeOut(500);
        });
        //确认删除
        $("#delbtn").click(function(){
            var id = $(this).attr("data-uuid");
            var obj = $(this);

            $.ajax({
                type: 'POST',
                url:addressDelete_url,
                dataType : "json" ,
                data:{
                    goodsAddressUuid:id
                },
                success:
                    function(data){

                        window.location.reload();

                    },
                error:
                    function(data,textStatus){

                    }
            });
        });


        //设为寄送地址
        $(".address_default2").click(function(){
            $(".adres2").empty();

            $(".address_default2").removeClass("address_default");
            $(".address_default2").text("设为寄送地址");
            $(this).addClass("address_default");
            $(this).text("寄送地址");
            $(this).append("<i class='iconfont defaulticon'>&#xe6e8;</i>");

            var n = $(this).next().children().eq(0).children().eq(0).text();
            var uui = $(this).next().children().eq(0).attr("id");
            var s1 = $(this).next().children().eq(0).children().eq(1).text();
            var s2 = $(this).next().children().eq(0).children().eq(2).text();
            var q = $(this).next().children().eq(0).children().eq(3).text();
            var x = $(this).next().children().eq(0).children().eq(4).text();
            var a = $(this).next().children().eq(0).children().eq(5).text();
            var t = $(this).next().children().eq(0).children().eq(6).text();
            $(".adres2").append("<span class='c1'>"+n+"</span>"+"&nbsp;&nbsp;"+"<span class='c2'>"+t+"</span>"+"<br>"+"<span class='c3'>"+s1+"</span>"+"<span class='c4'>"+s2+"</span>"+"<span class='c5'>"+q+"</span>"+"<span class='c6'>"+x+"</span>"+"<span class='c7'>"+a+"</span>");
            $(".adres2").attr("data-uid",uui);

            var productuuid = $(".pro_message").attr("data-id");
            $.ajax({
                type: 'POST',
                url:shopid_url,
                dataType : "json" ,
                data: "goodsAddressUuid=" + uui +"&productUuid=" + productuuid,
                success:
                    function(data){
                        $(".p2").text(data.shopName);
                        $("#pay").attr("data-id",data.shopId);
                        $(".pro_message").attr("data-ca",data.capacity);
                    },
                error:
                    function(data,textStatus){

                    }
            });



        });




        //鼠标移入显示
        $(".address_detail").mouseenter(function(){
            $(this).children("span").css("background-color","#fef9ef");
            $(this).children("span").children().eq(1).show();
            $(this).children("span").children().eq(2).show();
            $(this).children("span").children().eq(3).show();
        });
        //鼠标移出隐藏
        $(".address_detail").mouseleave(function(){

            var defa = $(this).children("span").children().eq(3).attr("data-default");
            $(this).children("span").css("background-color","#ffffff");
            $(this).children("span").children().eq(1).hide();
            $(this).children("span").children().eq(2).hide();
            if(defa ==0){
                $(this).children("span").children().eq(3).hide();
            }


        });
        var xjy="";
        //确认下单
        $("#pay").click(function(){

            var ca = $(".pro_message").attr("data-ca");
            $("#form").append("<input type='hidden' name='showCapacity' value='"+ca+"'>");
            var shopid1 = $(this).attr("data-id");
            var shopname = $("#sname").text();
            var name = $(".c1").text();
            var tel = $(".c2").text();
            var d1 = $(".c3").text();
            var d2 = $(".c4").text();
            var d3 = $(".c5").text();
            var d4 = $(".c6").text();
            var d5 = $(".c7").text();
            var detailaddress = d1+d2+d3+d4+d5;
            var total = $("#totalp").attr("data-allp");
            var uui = $(this).next().next().attr("data-uid");
            var bz = $("#beizhu").val();
            if(bz==""){
                bz=null;
            }else{
                bz=bz;
            }
            //xjy=productxjy+"&shopId="+shopid1+"&shopName="+shopname+"&receiveName="+name+"&receiveAddress="+detailaddress+"&receiveMobile="+tel+"&totalFromBdh="+total+"&goodsAddressUuid="+uui+"&note="+bz;
            //

            $("#v1").val(shopid1);
            $("#v2").val(shopname);
            $("#v3").val(name);
            $("#v4").val(detailaddress);
            $("#v5").val(tel);
            $("#v6").val(total);
            $("#v7").val(uui);
            $("#v8").val(bz);


            if(detailaddress==""){
                error("请选择一个配送地址");
                return false;
            }else if(shopid1==null||shopid1==""||shopid1==undefined){
                error("没有配送商家");
                return false;
            }else if(ca==0){
                error("库存不足");
                $("input[name=showCapacity]").remove();
                return false;
            }
            else{

                $("#form").submit();
            }



        });
    }




});