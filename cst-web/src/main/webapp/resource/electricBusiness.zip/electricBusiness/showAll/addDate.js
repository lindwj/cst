
//function cart(obj){
//
//
//    var productUuid = $(".imbuy").attr("data-uuid");
//    var ajaxURL = market_url;
//
//    jQuery.ajax({
//        url: ajaxURL,
//        cache : false,
//        data : {
//            num:"1",
//            productUuid:productUuid
//        },
//        success :
//            function(data) {
//
//                if (1 == data) {
//                    //mv();
//                    var num = parseInt($("#cart-num").text());
//                    num ++;
//                    $("#cart-num").text(num);
//                }
//            },
//        error:
//            function(data,textStatus){
//
//
//            }
//    });
//}
$(function () {




    //默认显示第一页的数据
    var localObj = window.location;
    var contextPath = localObj.pathname.split("/")[1];
    var basePath = localObj.protocol+"//"+localObj.host+"/"+contextPath;
    var server_context=basePath;

    //获取登录后进入的订单管理的链接
    var ajaxURL =  product_url;
    $.ajax({
        type: 'POST',
        url: ajaxURL,
        dataType : "json" ,
        data: {},

        success:
            function(data,textStatus){

                //显示订单管理第一页数据
                getOrderList(data.pList);


            },
        error:
            function(data,textStatus){


            }

    });





    //解析json数据，页面显示
    function getOrderList(info) {

        var product1 = "";
        var product2 = "";
        var product1_else = "";
        var product2_else = "";
        var product2_else1 = "";
        var menu = "";
        var pic = "";





        $.each(info, function (i, item) {
            var ordercode=window.location.href.split("=")[1];

            if(i==ordercode){

                product1_else = "";
                product2_else1 = "";
                product2_else = "";

                pic =  "<img src='"+ item.picture +"'>";
                menu = "<a href='"+index_url+"'>首页</a>"
                    +  "<p><i class='iconfont arrowicon'>&#xe63d;</i>"+ item.parameterName +"</p>";

                product1 = "<div class='floor1'>"
                    + "<div class='title1'>"
                    + "<p class='titl'>"
                    //+ "<img src='"+ item.icon +"'>"
                    + "<span>"+ item.parameterName + "</span>"
                    + "</h1>"
                    + "<div class='clear'>"
                    + "</div>"
                    + "<p class='titldesc'>"+ item.description +"</p>"
                    + "</div>"
                    + "<ul class='lfloor1'>";

                if (item.productList.length > 0) {

                    $.each(item.productList, function (n, ntem) {
                        var price = ntem.price;

                        if( price == 100000){
                            ntem.price = "即将上线";
                            if (n%2 == 0) {
                                product1_else = "<li class='product8' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    + "<img class='img' src=\"" + ntem.picForAll + "\"/>"
                                    + "</div>"
                                    + "<div class='descbox'>"
                                    + "<div class='desc'>"
                                        //+ "<h1>" + ntem.name + "<b>" + ntem.price.toFixed(2) + "</b>"
                                    + "<h1>" + ntem.name + "</h1>"
                                    + "<p class='descprice'>" + ntem.price + "</p>"
                                    + "<div class='clear'></div>"
                                    + "<p class='descp'>" + ntem.describes + "</p>"
                                    + "</div>"
                                    //+ "<a class='imbuy' data-uuid='"+ ntem.productUuid +"'><i class='iconfont marketicon'>&#xe600;</i>加入购物车</a>"
                                    + "<a class='imbuy' data-uuid='"+ ntem.productUuid +"'>立即查看</a>"
                                    + "<div class='clear'></div>"
                                    + "</div>"
                                    + "</li>"

                            }
                            else {

                                product1_else = "<li class='product7' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    + "<img class='img' src=\"" + ntem.picForAll + "\"/>"
                                    + "</div>"
                                    + "<div class='descbox'>"
                                    + "<div class='desc'>"
                                        //+ "<h1>" + ntem.name + "<b>" + ntem.price.toFixed(2) + "</b>"
                                    + "<h1>" + ntem.name + "</h1>"
                                    + "<p class='descprice'>" + ntem.price + "</p>"
                                    + "<div class='clear'></div>"
                                    + "<p class='descp'>" + ntem.describes + "</p>"
                                    + "</div>"
                                    //+ "<a class='imbuy' href='#' data-uuid='"+ ntem.productUuid +"'><i class='iconfont marketicon'>&#xe600;</i>加入购物车</a>"
                                    + "<a class='imbuy' data-uuid='"+ ntem.productUuid +"'>立即查看</a>"
                                    + "<div class='clear'></div>"
                                    + "</div>"
                                    + "</li>"

                            }
                        }else{
                            ntem.price = ntem.price;
                            if (n%2 == 0) {
                                product1_else = "<li class='product8' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                    //+ "<img src='" + ntem.pic + "'/>"
                                    + "<img class='img' src='" + ntem.picForAll + "'/>"
                                    + "</div>"
                                    + "<div class='descbox'>"
                                    + "<div class='desc'>"
                                    //+ "<h1>" + ntem.name + "<b>" + ntem.price.toFixed(2) + "</b>"
                                    + "<h1>" + ntem.name + "</h1>"
                                    + "<p class='descprice'><span>￥</span>" + ntem.price.toFixed(2) + "</p>"
                                    + "<div class='clear'></div>"
                                    + "<p class='descp'>" + ntem.describes + "</p>"
                                    + "</div>"
                                    //+ "<a class='imbuy' data-uuid='"+ ntem.productUuid +"'><i class='iconfont marketicon'>&#xe600;</i>加入购物车</a>"
                                    + "<a class='imbuy' data-uuid='"+ ntem.productUuid +"'>立即查看</a>"
                                    + "<div class='clear'></div>"
                                    + "</div>"
                                    + "</li>"

                            }
                            else {

                                product1_else = "<li class='product7' data-id='" + ntem.productUuid + "'>"
                                    + "<div class='imgbox1'>"
                                        //+ "<img src='" + ntem.pic + "'/>"
                                    + "<img class='img' src='" + ntem.picForAll + "'/>"
                                    + "</div>"
                                    + "<div class='descbox'>"
                                    + "<div class='desc'>"
                                        //+ "<h1>" + ntem.name + "<b>" + ntem.price.toFixed(2) + "</b>"
                                    + "<h1>" + ntem.name + "</h1>"
                                    + "<p class='descprice'><span>￥</span>" + ntem.price.toFixed(2) + "</p>"
                                    + "<div class='clear'></div>"
                                    + "<p class='descp'>" + ntem.describes + "</p>"
                                    + "</div>"
                                    //+ "<a class='imbuy' data-uuid='"+ ntem.productUuid +"'><i class='iconfont marketicon'>&#xe600;</i>加入购物车</a>"
                                    + "<a class='imbuy' data-uuid='"+ ntem.productUuid +"'>立即查看</a>"
                                    + "<div class='clear'></div>"
                                    + "</div>"
                                    + "</li>"
                            }
                        }

                        product2_else = product2_else + product1_else;
                        product1_else = "";
                    });

                    product2_else1 = product2_else + "</ul>" + "<div class='clear'>" + "</div>" + "</div>";

                    product2 += product1 + product2_else1;


                }
            }

        });
        $(".probanner").append(pic);
        $(".menu_box").append(menu);
        $(".allproduct").append(product2);



        ////购物车飞入效果
        //$(".imbuy").click(function(event){
        //    var start = $(this);
        //    var target = $(".shop").offset();
        //    var img = $(".img").attr('src');
        //    var flyer = $('<img class="u-flyer" src="'+img+'">');
        //    var winScrollTop = $(window).scrollTop();
        //    var shopScrollTop = $(".shop").scrollTop();
        //    flyer.fly({
        //        start: {
        //            left: start.offset().left +80 , //开始位置（必填）#fly元素会被设置成position: fixed
        //            top: start.offset().top - winScrollTop  //开始位置（必填）
        //        },
        //        end: {
        //            left: target.left + 60, //结束位置（必填）
        //            top: target.top + 10 - shopScrollTop, //结束位置（必填）
        //            width: 20, //结束时宽度
        //            height: 20 //结束时高度
        //        },
        //        onEnd: function(){ //结束回调
        //            flyer.remove();
        //            //修改购物车数量,延迟半秒钟修改
        //            cart(this,500)
        //        }
        //    });
        //
        //
        //});






        $(".product7").click(function(){
            var pid= $(this).attr("data-id");
            window.open(pro_url + pid);
        });
        $(".product8").click(function(){
            var pid= $(this).attr("data-id");
            window.open(pro_url + pid);
        });


    }


});