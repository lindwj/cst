
function onSelectChange(obj,toSelId){
    setSelect(obj.value,toSelId);
}
function setSelect(fromSelVal,toSelId){
    document.getElementById(toSelId).innerHTML="";
    jQuery.ajax({
        url: select_url,
        cache : false,
        data : "parent=" + fromSelVal,
        success : function(data) {
            createSelectObj(data, toSelId);
        }
    });
}
function createSelectObj(data, toSelId) {
    var arr = JSON.parse(data);
    if (arr != null && arr.length > 0) {

        if (toSelId == 'selstreet') {
            $("#"+toSelId).show();
        }


        var obj = document.getElementById(toSelId);
        obj.innerHTML = "";
        var nullOp = document.createElement("option");
        nullOp.setAttribute("value", "");
        nullOp.appendChild(document.createTextNode("请选择"));
        obj.appendChild(nullOp);
        for ( var o in arr) {
            var op = document.createElement("option");
            op.setAttribute("value", arr[o].id);
            //op.text=arr[o].name;//这一句在ie下不起作用，用下面这一句或者innerHTML
            if (toSelId == 'selprovince') {
                op
                    .appendChild(document
                        .createTextNode(arr[o].province));
            } else if (toSelId == 'selcity') {
                op.appendChild(document.createTextNode(arr[o].city));
            } else if (toSelId == 'seldistrict') {
                op
                    .appendChild(document
                        .createTextNode(arr[o].district));
            } else if (toSelId == 'selstreet') {
                op.appendChild(document.createTextNode(arr[o].street));
            }
            obj.appendChild(op);
        }
    }else{
        if (toSelId == 'selstreet') {
            var obj = document.getElementById(toSelId);
            $("#"+toSelId).hide();
        }
    }
}
setSelect('1', 'selprovince');

$(function(){


    var check = 1;
    $(".button").click(function(){

        var name1 = $("#name").val();
        var phone1 = $("#phone").val().trim();
        var check = $('input:radio[name="radio"]:checked').val();
        var bz1 = $("#bz").val();
        var p= $("#selprovince").val();
        var c= $("#selcity").val();
        var d= $("#seldistrict").val();




        var province1 = $("#selprovince").find("option:selected").text();
        var city1 = $("#selcity").find("option:selected").text();
        var district1 = $("#seldistrict").find("option:selected").text();

        var address1 = province1 + city1 + district1;

        if(name1 == ""){
            error("我的姓名不能为空");
            return false;
        }else if(phone1 == ""){
            error("我的电话不能为空");
            return false;
        }else if(p == ""){
            error("请选择省");
            return false;
        }else if(c == ""){
            error("请选择市");
            return false;
        }else if(d == ""){
            error("请选择区县");
            return false;
        }else{

            $.ajax({
                type:'post',
                url:contact_url,
                dataType:'json',
                data:{
                    name:name1,
                    telephone:phone1,
                    visit:check,
                    address:address1,
                    remark:bz1
                },
                success:
                    function(data){

                        if(data == 0){
                            error("我的姓名不能为空");
                            return false;
                        }else if(data == 1){
                            error("我的电话不能为空");
                            return false;
                        }else if(data == 2){
                            error("提交成功，我们会及时跟您联系！");
                            $("#name").val("");
                            $("#phone").val("");
                            $("#selprovince").val("");
                            $("#selcity").val("");
                            $("#seldistrict").val("");
                            //$("#bz").text("");
                            $("#bz").val("");
                            $("#radio1").attr("checked",true);
                            return false;
                        }
                    },
                error:
                    function(data){

                    }

            });
        }




    });



});